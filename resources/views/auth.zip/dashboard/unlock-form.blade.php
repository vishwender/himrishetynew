<div class="modal fade" id="unlockContactModal" tabindex="-1" aria-labelledby="unlockContactModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="unlockContactModalLabel">Unlock Contact</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('unlock.contact', $usr->id) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <p>
                        Unlocking this contact will cost 
                        <strong>{{ $usr->profile_view_price }} credits</strong> from your wallet.
                    </p>
                    <p>Your current balance: 
                        <strong>{{ $wallet->wallet_balance ?? 0 }}</strong> credits
                    </p>
                    @if(($wallet->wallet_balance ?? 0) < $usr->profile_view_price)
                        <div class="alert alert-danger">
                            You don’t have enough balance. Please recharge your wallet.
                        </div>
                    @endif
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    @if(($wallet->wallet_balance ?? 0) >= $usr->profile_view_price)
                        <button type="submit" class="btn btn-success">Confirm Unlock</button>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>