@extends('layouts.app')

@section('content')

<section class="banner_area">

    <div class="container">

        <div class="banner_inner_content">

            <h3>Terms & Conditions</h3>

            <ul>

                <li class="active"><a href="index-2.html">Home</a></li>

                <li><a href="#">Terms & Conditions</a></li>

            </ul>

        </div>

    </div>

</section>



<section class="page-section">

    <div class="container">

        <div class="page-box">

            <div class="explor_title row m0">

                <div class="left_ex_title1">

                    <h2><span>Terms</span> &amp; <span>Conditions</span></h2>

                    <p><b>OVERVIEW</b></p>

                    {!! $data !!}

                </div>

            </div>

            <!-- Page -->

        </div>

    </div>

</section>

@endsection