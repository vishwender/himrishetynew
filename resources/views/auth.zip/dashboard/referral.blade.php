<div class="modal fade" id="referral" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content text-center p-4">
            
            <div class="modal-header border-0">
                <button type="button" class="btn-close ms-auto clsbtn" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body">
                <h3 class="fw-bold mb-2">Feature Coming Soon</h3>
                <p class="text-muted">We’re working hard to launch this feature. Stay tuned!</p>
            </div>
            
        </div>
    </div>
</div>
