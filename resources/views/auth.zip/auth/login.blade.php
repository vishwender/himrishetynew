@extends('layouts.app')

@section('content')

<section class="banner_area">
    <div class="container">
        <div class="login_banner">
            <div class="banner_inner_content">
                <h3>Login</h3>
                <ul>
                    <li class="active"><a href="{{ route('welcome') }}">Home</a></li>
                    <li><a href="#">Login</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="page-section" style="padding:0px">
    <div class="container">
        <div class="page-box" style="/*width:800px;margin:0 auto;*/">
            <div class="explor_title row m0">
                <div class="left_ex_title">


                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="login-box">
                            <div class="center">
                                <div class="login-t1">Login And Find Your Perfect Match Here</div>
                                <div class="login-t2">Already a member? Please enter your User Id</div>
                            </div>
                            <div class="form-group col-md-12 no-padding">
                                <label>User ID/Mobile/Email</label><span class="req-star"><sup><i
                                            class="fa fa-star"></i></sup></span>
                                <input type="text" class="form-control" id="username" name="username" required />
                            </div>
                            @csrf
                            <div class="form-group col-md-12 no-padding">
                                <label>Password</label><span class="req-star"><sup><i
                                            class="fa fa-star"></i></sup></span>
                                <div class="input-group" id="show_hide_password">
                                    <input class="form-control" type="password" id="password" name="password" required>
                                    <div class="input-group-addon">
                                        <i class="fa fa-eye-slash toggle-password" aria-hidden="true"></i>
                                    </div>
                                </div>

                            </div>

                            <div>
                                <a href="{{ route('password.request') }}" class="login-fplink">Forgot Password</a>
                                <button id="login-button" type="button" class="btn btn-primary">Login</button>
                                <a href="javascript:void(0);" data-toggle="modal" data-target="#loginwithotp" id="login-with-otp"  class="btn btn-info"
                                    style="margin-left: 10px">Login with OTP</a> 
                            </div>
                            <hr>
                            <div id="login-message" class="center">

                            </div>
                            
                            <div class="center">
                                <div id="ajax-loader">
                                    <img src="{{ asset('assets/img/ajax-loader.gif') }}" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h4>A successful marriage depends on two things :</h4>
                        <ol>
                            <li>Finding the right person</li>
                            <li>Being the right person</li>
                        </ol>
                        <img class="border-img" src="{{ asset('assets/img/couple3.jpg') }}" />
                    </div>
                </div>
            </div>
            <!-- Page -->
        </div>
    </div>
    <!-- The modal -->
    <div class="modal fade" id="loginwithotp" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="phone-input">
                    <div class="form-group">
                        <label for="otp">Enter Register Phone Number</label>
                        <input type="text" class="form-control" id="otp" name="phone" required>
                        <input type="hidden" name="csrf" id="csrf" value="{{ csrf_token() }}">
                    </div>
                </div>
                <div class="modal-body" id="otp_verification" style="display:none">
                    <div class="form-group">
                        <label for="otp">Enter OTP</label>
                        <input type="text" class="form-control" id="verifyotp" name="otp" required>
                        <input type="hidden" name="csrf" id="csrf" value="{{ csrf_token() }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="generate-otp">Request OTP</button>
                    <button type="button" class="btn btn-secondary" id="mylogin" style="display:none" >Submit</button>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
$(document).on('click', '#login-button', function() {
    var user_name = $('#username').val();
    var password = $('#password').val();
    $.ajax({
        url: "{{ route('member-login') }}",
        type: "POST",
        data: {
            username: user_name,
            password: password,
            _token: $('input[name="_token"]').val(),
        },
        datatype: 'html',
        success: function(nor) {
            window.location = "{{ route('home') }}";
        }
    });
});
$(document).on('click','#generate-otp',function(){
	var phone = $('#otp').val();
    var csrf = $('#csrf').val();
    $.ajax({
        url: "{{ route('login-with-otp') }}",
        type: "POST",
        data: {
            phone: phone,
            _token: csrf,
        },
        datatype: 'html',
        success: function(nor) {
            $('#phone-input').hide();
            $('#otp_verification').show();
            $('#generate-otp').hide();
            $('#mylogin').css('display','block');
        }
    });
});

$(document).on('click','#mylogin',function(){
    var otp = $('#verifyotp').val();
    var csrf = $('#csrf').val();
    $.ajax({
        url: "{{ route('verify-login-otp') }}",
        type: "POST",
        data: {
            otp: otp,
            _token: csrf,
        },
        datatype: 'html',
        success: function(nor) {
            console.log(nor);
            window.location = "{{ route('home') }}";
        }
    });
})
</script>
@endsection