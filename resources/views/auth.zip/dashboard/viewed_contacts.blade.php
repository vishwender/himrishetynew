@extends('dashboard.layouts.app')
@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="row">
            @foreach($data['contacts'] as $recent)
            <div class="col-md-4">
                <a href="javascript:void(0)" class="viewProfile"
                            data-url="{{ route('view-profile', ['id' => $recent['id']]) }}"
                            data-id="{{ $recent['id'] }}">
                    <div class="card mb-3 card-width">
                        <img class="card-img-top" src="{{ $recent['photo'] }}" height="380"
                                    alt="Card image cap">
                        <div class="product-detail">
                            <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                            <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }}
                                        |
                                        {{ $recent['cast'] }}</span>
                            <blockquote>
                                <p>{{ $recent['religion'] }}</p>
                                <p>{{ $recent['education'] }}</p>
                                <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                            </blockquote>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection