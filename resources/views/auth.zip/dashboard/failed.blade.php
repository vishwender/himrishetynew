@extends('dashboard.layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-lg border-0 text-center">
                <div class="card-header bg-danger text-white">
                    <h3 class="mb-0">Payment Failed ❌</h3>
                </div>
                <div class="card-body">
                    <h4>Sorry, {{ Auth::user()->name }}!</h4>
                    <p class="lead">Your payment could not be processed. Please try again.</p>

                    <div class="alert alert-warning mt-3">
                        If the amount was deducted from your account, it will be refunded automatically by Razorpay within a few days.
                    </div>

                    <a href="{{ route('auth:member') }}" class="btn btn-primary mt-3">Try Again</a>
                    <a href="{{ route('auth:member') }}" class="btn btn-secondary mt-3">Go to Dashboard</a>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
