@extends('dashboard.layouts.app')
@section('content')
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<div class="container d-flex justify-content-center mt-20" id="myProfiletabs">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-5">
        <div class="tab-vertical">
            <ul class="nav nav-tabs mr-3" id="myTab3" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="profile-vertical-tab" data-toggle="tab" href="#profile-vertical" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="basic-vertical-tab" data-toggle="tab" href="#basic-vertical" role="tab" aria-controls="basic" aria-selected="false">Basic Info</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="astro-vertical-tab" data-toggle="tab" href="#astro-vertical" role="tab" aria-controls="astro" aria-selected="false">Astro and Kundali Details</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-vertical-tab" data-toggle="tab" href="#contact-vertical" role="tab" aria-controls="contact" aria-selected="false">Contact Details</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="religion-vertical-tab" data-toggle="tab" href="#religion-vertical" role="tab" aria-controls="religion" aria-selected="false">Religion Information</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="lifestyle-vertical-tab" data-toggle="tab" href="#lifestyle-vertical" role="tab" aria-controls="lifestyle" aria-selected="false">Lifestyle</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="family-vertical-tab" data-toggle="tab" href="#family-vertical" role="tab" aria-controls="family" aria-selected="false">Family Details</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="career-vertical-tab" data-toggle="tab" href="#career-vertical" role="tab" aria-controls="career" aria-selected="false">Career & Education</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="partner-vertical-tab" data-toggle="tab" href="#partner-vertical" role="tab" aria-controls="partner" aria-selected="false">Partner Preferences</a>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent3">
                <div class="tab-pane fade show active" id="profile-vertical" role="tabpanel" aria-labelledby="profile-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span>Profile</h3>
                    <div class="profile_card_5">
                        <div class="cover-photo text-center">
                            <div class="profile-wrapper">
                                @if($user->photo != null)
                                <img src="https://himrishtey.com/photos/photo/{{$user->photo}}" class="profile">
                                @else
                                @if($user->gender == 'Male')
                                <img src="https://himrishtey.com/img/boy.jpg" class="profile">
                                @elseif($user->gender == 'Female')
                                <img src="https://himrishtey.com/img/girl.jpg" class="profile">
                                @else
                                <img src="https://himrishtey.com/img/no-image.jpg" class="profile">
                                 @endif
                                @endif
                                <label for="upload-photo" class="camera-btn">
                                    <span class="ti-camera"></span>
                                </label>
                                <input type="file" id="upload-photo" name="photo" class="d-none" accept="image/*">
                            </div>
                        </div>
                        <div class="profile-name">{{$user->full_name}}</div>
                        <div class="Activity_timeline">
                            <ul>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>{{$user->profile_id }}</h6>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>{{$user->email }}</h6>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>{{$plan->plan_name ? $plan->plan_name : 'Free' }}</h6>
                                    </div>
                                </li>
                                <hr>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Relationship Manager</h6>
                                        <p>Name:
                                            {{ $user->relationship_manager ? $user->relationship_manager : 'N/A'}}
                                        </p>
                                        <p> Contact: {{ $rm->phone ? $rm->phone : 'N/A'}}</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>    
                </div>
                <div class="tab-pane fade" id="basic-vertical" role="tabpanel" aria-labelledby="basic-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span>Basic Info <a href="javascript:void('0');" class="info-form"
                                        data-id="basic-info"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="basic-info-details">
                            <p class="about">{{ $user->about_me }}</p>
                            <p class="about">Created by : {{ $data['profile_created_by'] }} | {{ $user->age_years }}
                                Years |
                                {{ $user->height }} ft | Profile Id : {{ $user->profile_id}} | {{$user->religion }}</p>
                            <p class="about">{{ $user->cast }} | {{ $user->city_living_in}} |
                                {{ $user->marital_status }}
                            </p>
                        </div>
                        <div class="profile_card_5 d-none" id="basic-info-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">About Me</label>
                                    <textarea class="form-control" name="about_me" id="inputAddress"
                                        rows="3">{{ $user->about_me }}</textarea>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Profile Created By</label>
                                    <select class="form-control" name="profile_created_for"
                                        id="exampleFormControlSelect1">
                                        @foreach($data['profile_created_for'] as $profile_created_for)
                                        <option value="{{ $profile_created_for->value }}"
                                            {{ $profile_created_for->value == $user->profile_created_for ? 'selected' : '' }}>
                                            {{ $profile_created_for->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Date of Birth</label>
                                    <input class="form-control" name="date_of_birth" type="text" id="edit_datepicker"
                                        value="{{ $user->birth_date_time->format('Y-m-d'); }}"
                                        placeholder="Pick a start date">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Time of Birth</label>
                                    <input class="form-control" name="time_of_birth" type="text" id="edit_timepicker"
                                        value="{{ $user->birth_date_time->format('H-i-s'); }}"
                                        placeholder="Pick time of birth">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Height</label>
                                    <select class="form-control" name="height" id="exampleFormControlSelect1">
                                        @foreach($data['heights'] as $height)
                                        <option value="{{ $height->height_value }}"
                                            {{ $height->height_value == $user->height ? 'selected' : '' }}>
                                            {{ $height->height_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Religion</label>
                                    <select class="form-control" name="religion" id="exampleFormControlSelect1">
                                        @foreach($data['religions'] as $religion)
                                        <option value="{{ $religion->religion }}"
                                            {{ $religion->religion == $user->religion ? 'selected' : '' }}>
                                            {{ $religion->religion }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Cast</label>
                                    <select class="form-control" name="cast" id="exampleFormControlSelect1">
                                        @foreach($data['casts'] as $cast)
                                        <option value="{{ $cast->cast }}"
                                            {{ $cast->cast == $user->cast ? 'selected' : '' }}>{{ $cast->cast }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Cast</label>
                                    <select class="form-control" name="marital_status" id="exampleFormControlSelect1">
                                        @foreach($data['marital_statuses'] as $ms)
                                        <option value="{{ $ms->marital_status }}"
                                            {{ $ms->marital_status == $user->marital_status ? 'selected' : '' }}>
                                            {{ $ms->marital_status }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if($user->marital_status != 'Never Married' || $user->no_of_child > 0)
                                <div class="form-group m-2">
                                    <label for="inputAddress">No. Of Child(ren)</label>
                                    <select class="form-control" name="no_of_child" id="exampleFormControlSelect1">
                                        @for($i = 0; $i <= 5 ; $i++) <option value="{{ $i }}"
                                            {{ $i == $user->no_of_child ? 'selected' : '' }}>{{ $i }}</option>
                                            @endfor
                                    </select>
                                </div>
                                @endif
                                <div class="form-group m-2">
                                    <label for="inputAddress">Country</label>
                                    <select class="form-control" name="country_living_in"
                                        id="exampleFormControlSelect1">
                                        @foreach($data['countries'] as $country)
                                        <option value="{{ $country->name }}"
                                            {{ $country->name == $user->country_living_in ? 'selected' : '' }}>
                                            {{ $country->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">State</label>
                                    <select class="form-control" name="state_living_in" id="exampleFormControlSelect1">
                                        @foreach($data['states'] as $state)
                                        <option value="{{ $state->name }}"
                                            {{ $state->name == $user->state_living_in ? 'selected' : '' }}>
                                            {{ $state->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">City</label>
                                    <select class="form-control" name="city_living_in" id="exampleFormControlSelect1">
                                        @foreach($data['cities'] as $city)
                                        <option value="{{ $city->name }}"
                                            {{ $city->name == $user->city_living_in ? 'selected' : '' }}>
                                            {{ $city->name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>    
                </div>
                <div class="tab-pane fade" id="astro-vertical" role="tabpanel" aria-labelledby="astro-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span>Astro and Kundali Details <a href="javascript:void('0');"
                                        class="info-form" data-id="astro-kundali"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="astro-kundali-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Date Of Birth</h6>
                                            <p>{{ $user->birth_date_time ? $user->birth_date_time->format('d-m-Y') : 'N/A' }}
                                            </p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Time Of Birth</h6>
                                            <p>{{ $user->birth_date_time ? $user->birth_date_time->format('h:i A') : 'N/A' }}
                                            </p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Place of Birth</h6>
                                            <p>{{ $user->birth_place ? $user->birth_place : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Manglik</h6>
                                            <p>{{ $user->manglik ? $user->manglik : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="astro-kundali-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">Date Of Birth</label>
                                    <p>{{ $user->birth_date_time->format('d-m-Y') }}</p>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Time Of Birth</label>
                                    <p>{{ $user->birth_date_time->format('h:i A') }}</p>

                                    <a href="javascript:void('0');" class="date-time" id="date-time">To edit date &
                                        time,
                                        Click Here..</a>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Place Of Birth</label>
                                    <input type="text" class="form-control" name="birth_place" id="inputAddress"
                                        value="{{ $user->birth_place }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Manglik</label>
                                    <select class="form-control" name="manglik" id="exampleFormControlSelect1">
                                        <option value="">Select</option>
                                        <option value="Yes" {{ $user->manglik == 'Yes' ? 'selected' : '' }}>Yes</option>
                                        <option valye="No" {{ $user->manglik == 'No' ? 'selected' : '' }}>No</option>
                                    </select>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>    
                </div>
                <div class="tab-pane fade" id="contact-vertical" role="tabpanel" aria-labelledby="contact-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span>Contact Details <a a href="javascript:void('0');" class="info-form"
                                        data-id="contact-details"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="contact-details-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Contact Number</h6>
                                            <p>{{ $user->mobile_number ? $user->mobile_number : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Alternate Contact Number</h6>
                                            <p>{{ $user->alternate_number ? $user->alternate_number : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>WhatsApp Number</h6>
                                            <p>{{ $user->whatsapp_number ? $user->whatsapp_number : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Email Address</h6>
                                            <p>{{ $user->email ? $user->email : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="contact-details-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">Contact Number</label>
                                    <input type="text" class="form-control" name="mobile_number"
                                        value="{{ $user->mobile_number }}" id="inputAddress" disabled>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Alternate Contact Number</label>
                                    <input type="text" class="form-control" name="alternate_number"
                                        value="{{ $user->alternate_number }}" id="inputAddress">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">WhatsApp Number</label>
                                    <input type="text" class="form-control" name="whatsapp_number"
                                        value="{{ $user->whatsapp_number }}" id="inputAddress">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Email Address</label>
                                    <input type="email" class="form-control" name="email" value="{{ $user->email }}"
                                        id="inputAddress" disabled>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>    
                </div>
                <div class="tab-pane fade" id="religion-vertical" role="tabpanel" aria-labelledby="religion-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span> Religion Information <a a href="javascript:void('0');"
                                        class="info-form" data-id="religion-info"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="religion-info-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Community</h6>
                                            <p>{{ $user->cast ? $user->cast : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Sub Community</h6>
                                            <p>{{ $user->sub_cast ? $user->sub_cast : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Gotra</h6>
                                            <p>{{ $user->gotra ? $user->gotra : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="religion-info-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">Community</label>
                                    <select class="form-control" name="cast" id="exampleFormControlSelect1">
                                        @foreach($data['casts'] as $cast)
                                        <option value="{{ $cast->cast }}"
                                            {{ $cast->cast == $user->cast ? 'selected' : '' }}>{{ $cast->cast }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Sub Community</label>
                                    <input type="text" class="form-control" name="sub_cast"
                                        value="{{ $user->sub_cast }}" id="inputAddress">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Gotra</label>
                                    <input type="text" class="form-control" name="gotra" value="{{ $user->gotra }}"
                                        id="inputAddress">
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>    
                </div>
                <div class="tab-pane fade" id="lifestyle-vertical" role="tabpanel" aria-labelledby="lifestyle-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span> Lifestyle<a a href="javascript:void('0');" class="info-form"
                                        data-id="lifestyle"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="lifestyle-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Diet</h6>
                                            <p>{{ $user->diet ? $user->diet : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Smoking</h6>
                                            <p>{{ $user->is_smoking ? $user->is_smoking : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Drinking</h6>
                                            <p>{{ $user->is_drinking ? $user->is_drinking : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Any Disability</h6>
                                            <p>{{ $user->any_disability ? $user->any_disability : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="lifestyle-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">Diet</label>
                                    <select class="form-control" name="diet" id="exampleFormControlSelect1">
                                        <option value="">Select</option>
                                        <option value="Veg" {{ $user->diet == 'Veg' ? 'selected' : '' }}>Veg</option>
                                        <option value="Veg & Non-veg"
                                            {{ $user->diet == 'Veg & Non-veg' ? 'selected' : '' }}>Veg & Non-veg
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Smoking</label>
                                    <select class="form-control" name="is_smoking" id="exampleFormControlSelect1">
                                        <option value="">Select</option>
                                        <option value="Yes" {{ $user->is_smoking == 'Yes' ? 'selected' : '' }}>Yes
                                        </option>
                                        <option value="No" {{ $user->is_smoking == 'No' ? 'selected' : '' }}>No</option>
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Drinking</label>
                                    <select class="form-control" name="is_drinking" id="exampleFormControlSelect1">
                                        <option value="">Select</option>
                                        <option value="Yes" {{ $user->is_drinking == 'Yes' ? 'selected' : '' }}>Yes
                                        </option>
                                        <option value="No" {{ $user->is_drinking == 'No' ? 'selected' : '' }}>No
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Any Disability</label>
                                    <textarea class="form-control" name="any_disability" id="any_disability" cols="30"
                                        rows="3">{{ $user->any_disability }}</textarea>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>
                </div>
                <div class="tab-pane fade" id="family-vertical" role="tabpanel" aria-labelledby="family-vertical-tab">
                    <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span> Family Details <a a href="javascript:void('0');" class="info-form"
                                        data-id="family"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="family-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>About My Family</h6>
                                            <p>{{ $user->about_family ? $user->about_family : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Family Type</h6>
                                            <p>{{ $user->family_type ? $user->family_type : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Native Place</h6>
                                            <p>{{ $user->native_place ? $user->native_place : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Father Name</h6>
                                            <p>{{ $user->father_name ? $user->father_name : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Father Occupation</h6>
                                            <p>{{ $user->father_occupation ? $user->father_occupation : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Mother Name</h6>
                                            <p>{{ $user->mother_name ? $user->mother_name : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Mother Occupation</h6>
                                            <p>{{ $user->mother_occupation ? $user->mother_occupation : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Brother</h6>
                                            <p>{{ $user->no_of_brothers ? $user->no_of_brothers : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Married Brother</h6>
                                            <p>{{ $user->married_brothers ? $user->married_brothers : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Sister</h6>
                                            <p>{{ $user->no_of_sisters ? $user->no_of_sisters : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Married Sister</h6>
                                            <p>{{ $user->married_sisters ? $user->married_sisters : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="family-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">About My Family</label>
                                    <textarea class="form-control" name="about_my_family" id="about_my_family" cols="30"
                                        rows="3">{{ $user->about_family  }}</textarea>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Family Type</label>
                                    <select class="form-control" name="family_type" id="family_type">
                                        <option value=""></option>
                                        @foreach($data['familyStatuses'] as $family_type)
                                        <option value="{{ $family_type->value }}"
                                            {{ $family_type->value == $user->family_status ? 'selected' : '' }}>
                                            {{ $family_type->value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Native Place</label>
                                    <input type="text" class="form-control" name="native_place" id="father_name"
                                        value="{{ $user->native_place }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Father Name</label>
                                    <input type="text" class="form-control" name="father_name" id="father_name"
                                        value="{{ $user->father_name }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Father Occupation</label>
                                    <input type="text" class="form-control" name="father_occupation"
                                        id="father_occupation" value="{{ $user->father_occupation }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Mother Name</label>
                                    <input type="text" class="form-control" name="mother_name" id="mother_name"
                                        value="{{ $user->mother_name }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Mother Occupation</label>
                                    <input type="text" class="form-control" name="mother_occupation"
                                        id="mother_occupation" value="{{ $user->mother_occupation }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Brother</label>
                                    <input type="text" class="form-control" name="no_of_brothers" id="no_of_brothers"
                                        value="{{ $user->no_of_brothers }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Married Brother</label>
                                    <input type="text" class="form-control" name="married_brothers"
                                        id="married_brothers" value="{{ $user->married_brothers }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Sister</label>
                                    <input type="text" class="form-control" name="no_of_sisters" id="no_of_sisters"
                                        value="{{ $user->no_of_sisters }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Married Sister</label>
                                    <input type="text" class="form-control" name="married_sisters" id="married_sisters"
                                        value="{{ $user->married_sisters }}">
                                </div>
                                <div class="form-group m-2">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>    
                </div>
                <div class="tab-pane fade" id="career-vertical" role="tabpanel" aria-labelledby="career-vertical-tab">
                   <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span> Career & Education<a a href="javascript:void('0');" class="info-form"
                                        data-id="career-education"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="career-education-details">
                            <div class="Activity_timeline">
                                <ul>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>About my career & Education</h6>
                                            <p>{{ $user->about_my_education ? $user->about_my_education : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Education</h6>
                                            <p>{{ $user->education ? $user->education : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Other Qualification</h6>
                                            <p>{{ $user->any_other_qualifications ? $user->any_other_qualifications : 'N/A' }}
                                            </p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Employed in</h6>
                                            <p>{{ $user->employed_in ? $user->employed_in : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Occupation</h6>
                                            <p>{{ $user->occupation ? $user->occupation : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Job Location</h6>
                                            <p>{{ $user->job_location ? $user->job_location : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Currently Working</h6>
                                            <p>{{ $user->organization_name ? $user->organization_name : 'N/A' }}</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="activity_bell"></div>
                                        <div class="activity_wrap">
                                            <h6>Annual Income</h6>
                                            <p>{{ $user->annual_income ? $user->annual_income : 'N/A' }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="profile_card_5 d-none" id="career-education-form">
                            <form action="{{ route('update-profile') }}" method="post">
                                @csrf
                                <div class="form-group m-2">
                                    <label for="inputAddress">About my career & Education</label>
                                    <textarea class="form-control" name="about_my_education" id="about_my_education"
                                        cols="30" rows="3">{{ $user->about_my_education }}</textarea>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Education</label>
                                    <select class="form-control" name="education" id="education">
                                        <option value=""></option>
                                        @foreach($data['educations'] as $education)
                                        <option value="{{ $education->education }}"
                                            {{ $education->education == $user->education ? 'selected' : '' }}>
                                            {{ $education->education }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Other Qualification</label>
                                    <input type="text" class="form-control" name="any_other_qualifications"
                                        id="any_other_qualifications"
                                        value="{{ $user->any_other_qualifications ? $user->any_other_qualifications : 'N/A' }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Employed in</label>
                                    <select class="form-control" name="employed_in" id="employed_in">
                                        <option value=""></option>
                                        @foreach($data['employers'] as $employed_in)
                                        <option value="{{ $employed_in->value }}"
                                            {{ $employed_in->employer == $user->employed_in ? 'selected' : '' }}>
                                            {{ $employed_in->employer }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Occupation</label>
                                    <input type="text" class="form-control" name="occupation" id="occupation"
                                        value="{{ $user->occupation }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Job Location</label>
                                    <input type="text" class="form-control" name="job_location" id="job_location"
                                        value="{{ $user->job_location }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Currently Working</label>
                                    <input type="text" class="form-control" name="organization_name"
                                        id="organization_name" value="{{ $user->organization_name }}">
                                </div>
                                <div class="form-group m-2">
                                    <label for="inputAddress">Annual Income</label>
                                    <input type="text" class="form-control" name="annual_income" id="annual_income"
                                        value="{{ $user->annual_income }}">
                                </div>
                                <div class="form-group m-2">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                </div>
                <div class="tab-pane fade" id="partner-vertical" role="tabpanel" aria-labelledby="partner-vertical-tab">
                   <h3 class="mb-2"><span class="mr-2 color-theme"><i class="ti-joomla"></i></span> Partner Preferences <a href="javascript:void('0');" class="info-form"
                                    data-id="partner-preferences"><i class="ti-pencil"></i></a></h3>
                    <div class="profile_card_5" id="partner-preferences-details">
                        <div class="Activity_timeline">
                            <ul>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>About My Partner</h6>
                                        <p>{{ $user->about_my_partner ? $user->about_my_partner : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>height</h6>
                                        <p>{{ $user->partner_height_from ? $user->partner_height_from : '0' }} -
                                            {{ $user->partner_height_to ? $user->partner_height_to : '0' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Age</h6>
                                        <p>{{ $user->partner_age_from ? $user->partner_age_from : '0' }} -
                                            {{ $user->partner_age_to ? $user->partner_age_to : '0' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Marital Status</S></h6>
                                        <p>{{ $user->looking_for ? $user->looking_for : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Religion & Mother Tongue</h6>
                                        <p>{{ $user->partner_mothertongue ? $user->partner_mothertongue : 'N/A' }} |
                                            {{ $user->partner_religion ? $user->partner_religion : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Community</h6>
                                        <p>{{ $user->partner_cast ? $user->partner_cast : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Is Manglik</h6>
                                        <p>{{ $user->is_partner_manglik ? $user->is_partner_manglik : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Heightest Qualification</h6>
                                        <p>{{ $user->partner_education ? $user->partner_education : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Annual Income</h6>
                                        <p>{{ $user->partner_annual_income_from ? $user->partner_annual_income_from : '0.0' }}
                                            -
                                            {{ $user->partner_annual_income_to ? $user->partner_annual_income_to : '0.0' }}
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Diet</h6>
                                        <p>{{ $user->partner_diet ? $user->partner_diet : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Drinking</h6>
                                        <p>{{ $user->is_partner_drinking ? $user->is_partner_drinking : 'N/A' }}</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="activity_bell"></div>
                                    <div class="activity_wrap">
                                        <h6>Smoking</h6>
                                        <p>{{ $user->is_partner_smoking ?  $user->is_partner_smoking : 'N/A' }}</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="profile_card_5 d-none" id="partner-preferences-form">
                        <form action="{{ route('update-profile') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Age From</label>
                                        <select class="form-control" name="partner_age_from" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @for($i = 18; $i <= 60 ; $i++) 
                                            <option value="{{ $i }}" {{ $i == $user->partner_age_from ? 'selected' : '' }}>{{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Age To</label>
                                        <select class="form-control" name="partner_age_to" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @for($i = 18; $i <= 60 ; $i++) 
                                            <option value="{{ $i }}" {{ $i == $user->partner_age_to ? 'selected' : '' }}>{{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Height From</label>
                                        <select class="form-control" name="partner_height_from" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @foreach($data['heights'] as $height) 
                                            <option value="{{ $height->height }}"
                                                {{ $height->height == $user->partner_height_from ? 'selected' : '' }}>{{ $height->height }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Height To</label>
                                        <select class="form-control" name="partner_height_to" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @foreach($data['heights'] as $height) 
                                            <option value="{{ $height->height }}"
                                                {{ $height->height_height == $user->partner_height_from ? 'selected' : '' }}>{{ $height->height }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Annual Income From</label>
                                        <select class="form-control" name="partner_annual_income_from" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @foreach($data['annualIncomes'] as $annualIncome) 
                                            <option value="{{ $annualIncome->annual_income }}"
                                                {{ $annualIncome->annual_income == $user->partner_annual_income_from ? 'selected' : '' }}>{{ $annualIncome->annual_income }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group m-2">
                                        <label for="inputAddress">Partner Annual Income From</label>
                                        <select class="form-control" name="partner_annual_income_to" id="exampleFormControlSelect1">
                                            <option value="">Select</option>
                                            @foreach($data['annualIncomes'] as $annualIncome) 
                                            <option value="{{ $annualIncome->annual_income }}"
                                                {{ $annualIncome->annual_income == $user->partner_annual_income_to ? 'selected' : '' }}>{{ $annualIncome->annual_income }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group m-2">
                                <label for="inputAddress">About My Partner</label>
                                <textarea class="form-control" name="about_my_partner" id="inputAddress"
                                    rows="3">{{ $user->about_my_partner }}</textarea>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Marital Status</label>
                                <select class="form-control" name="looking_for[]" id="partner_marital_status" multiple="multiple">
                                    @foreach($data['marital_statuses'] as $marital_status) 
                                    <option value="{{ $marital_status->marital_status }}" @if(!empty($user->looking_for ) && in_array($marital_status->marital_status, explode(',',$user->looking_for) )) selected @endif>{{ $marital_status->marital_status }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Religion</label>
                                <select class="form-control" name="partner_religion[]" id="partner_religion" multiple="multiple">
                                    @foreach($data['religions'] as $religion) 
                                    <option value="{{ $religion->religion }}" @if(!empty($user->partner_religion ) && in_array($religion->religion, explode(',',$user->partner_religion) )) selected @endif>{{ $religion->religion }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Cast</label>
                                <select class="form-control" name="partner_cast[]" id="partner_cast" multiple="multiple">
                                    @foreach($data['casts'] as $cast) 
                                    <option value="{{ $cast->cast }}" @if(!empty($user->partner_cast ) && in_array($cast->cast, explode(',',$user->partner_cast) )) selected @endif> {{ $cast->cast }} </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Mother Tongue</label>
                                <select class="form-control" name="partner_mothertongue[]" id="partner_mother_tongue" multiple="multiple">
                                    @foreach($data['motherTongues'] as $mt) 
                                    <option value="{{ $mt->mother_tongue }}" @if(!empty($user->partner_mothertongue ) && in_array($mt->mother_tongue, explode(',',$user->partner_mothertongue) )) selected @endif> {{ $mt->mother_tongue }} </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Manglik</label>
                                <select class="form-control" name="is_partner_manglik">
                                    <option value="">Select</option>
                                    <option value="Yes" {{ $user->is_partner_manglik == "Yes" ? 'selected' : '' }}>Yes</option>
                                    <option value="No" {{ $user->is_partner_manglik == "No" ? 'selected' : '' }}>No</option>
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Highest Qualification</label>
                                <select class="form-control" name="partner_education[]" id="partner_highest_qualification" multiple="multiple">
                                    @foreach($data['educations'] as $education) 
                                    <option value="{{ $education->education }}"  @if(!empty($user->partner_education ) && in_array($education->education, explode(',',$user->partner_education) )) selected @endif>{{ $education->education }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Employed In</label>
                                <select class="form-control" name="partner_employed_in[]" id="partner_employed_in" multiple="multiple">
                                    @foreach($data['employers'] as $employer) 
                                    <option value="{{ $employer->employer }}" @if(!empty($user->partner_occupation ) && in_array($employer->employer, explode(',',$user->partner_occupation) )) selected @endif>{{ $employer->employer }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Partner Diet</label>
                                <select class="form-control" name="partner_diet">
                                    <option value="">Select</option>
                                    <option value="Veg" {{ $user->partner_diet == "Veg" ? 'selected' : '' }}>Veg</option>
                                    <option value="VEg & Non Veg" {{ $user->partner_diet == "Veg & Non Veg" ? 'selected' : '' }}>Veg & Non Veg</option>
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Smoking</label>
                                <select class="form-control" name="is_partner_smoking">
                                    <option value="">Select</option>
                                    <option value="Yes" {{ $user->is_partner_smoking == "Yes" ? 'selected' : '' }}>Yes</option>
                                    <option value="No" {{ $user->is_partner_smoking == "No" ? 'selected' : '' }}>No</option>
                                </select>
                            </div>
                            <div class="form-group m-2">
                                <label for="exampleFormControlSelect1" class="form-label" >Drinking</label>
                                <select class="form-control" name="is_partner_drinking">
                                    <option value="">Select</option>
                                    <option value="Yes" {{ $user->is_partner_drinking == "Yes" ? 'selected' : '' }}>Yes</option>
                                    <option value="No" {{ $user->is_partner_drinking == "No" ? 'selected' : '' }}>No</option>
                                </select>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Update">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    $(document).on('click', '.info-form', function() {
        var id = $(this).attr('data-id');
        $('#' + id + '-details').toggleClass('d-none');
        $('#' + id + '-form').toggleClass('d-none');
        $('#partner_marital_status').select2({
            width: '100%'
        });
    });

    $(document).on('click', '.date-time', function() {
        $('#astro-kundali-form').toggleClass('d-none');
        $('#astro-kundali-details').toggleClass('d-none');
        $('#basic-info-form').toggleClass('d-none');
        $('#basic-info-details').toggleClass('d-none');
    });
});
</script>
@endsection