<nav class="sidebar">
    <div class="logo d-flex justify-content-between">
        <a href="#"><img src="{{ asset('assets/logo.png') }}" alt=""></a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>
    <ul id="sidebar_menu">
        <li class="mm-active">
            <a href="{{ route('home') }}" aria-expanded="false">
                <img src="{{ asset('assets/user/img/menu-icon/1.svg') }}" alt="">
                <span>Home</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{route('memberships')}}" id="membership_page"
                aria-expanded="false">
                <i class="ti-crown"></i>
                <span>Membership</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('profile') }}" aria-expanded="false">
                <i class="ti-user"></i>
                <span>Edit Profile</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('quick-search') }}" aria-expanded="false">
                <img src="{{ asset('assets/user/img/icon/icon_search.svg') }}" alt="">
                <span>Quick Search</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('advance-search') }}" aria-expanded="false">
                <img src="{{ asset('assets/user/img/icon/icon_search.svg') }}" alt="">
                <span>Advance search</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('search-by-profile-id') }}" aria-expanded="false">
                <img src="{{ asset('assets/user/img/icon/icon_search.svg') }}" alt="">
                <span>Search By Profile Id</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('interest-box') }}" aria-expanded="false">
                <i class="fas fa-inbox"></i>
                <span>Interest Box</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('view-my-profile') }}" aria-expanded="false">
                <i class="ti-user"></i>
                <span>View My Profile</span>
            </a>
        </li>
        <li class="">
            <a href="#" aria-expanded="false" id="change_password">
                <i class="ti-bell"></i>
                <span>Change Password</span>
            </a>
        </li>
        <li class="">
            <a href="{{ route('viewed-contacts') }}" aria-expanded="false">
                <i class="ti-eye"></i>
                <span>View Contacts</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{route('referral')}}" id="referearn" aria-expanded="false">
                <i class="ti-sharethis"></i>
                <span>Refer & Earn</span>
            </a>
        </li>
        <li class="">
            <a href="{{route('success_stories') }}" aria-expanded="false">
                <i class="ti-comments-smiley"></i>
                <span>Success Stories</span>
            </a>
        </li>
        <li class="">
            <a href="#" aria-expanded="false">
                <i class="ti-trash"></i>
                <span>Delete Profile</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{ route('user-refund') }}" id="refund" aria-expanded="false">
                <i class="ti-close"></i>
                <span>Refund & Cancellation</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{route('user-privacy-policy')}}" id="privacy" aria-expanded="false">
                <i class="ti-help-alt"></i>
                <span>Privacy Policy</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{route('user-rating')}}" id="rating" aria-expanded="false">
                <i class="ti-stamp"></i>
                <span>Rate Us</span>
            </a>
        </li>
        <li class="">
            <a href="tel:9857102002" aria-expanded="false">
                <i class="ti-headphone"></i>
                <span>Helpline Number</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:void('0')" data-url="{{route('user-terms-and-conditions')}}" id="term-condition"
                aria-expanded="false">
                <i class="ti-settings"></i>
                <span>Terms & Conditions</span>
            </a>
        </li>
        <li>
            <form id="logout-form" action="{{ route('member-logout') }}" method="POST">
                @csrf
                <button type="submit" class="d-flex align-items-center" style="background:none; border:none; padding:0; color:inherit; cursor:pointer;">
                    <span><i class="ti-shift-right"></i></span>
                    <span class="ms-4">Log Out</span>
                </button>
            </form>
        </li>

        
    </ul>
</nav>