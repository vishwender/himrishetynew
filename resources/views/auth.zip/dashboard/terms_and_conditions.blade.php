<div class="modal fade" id="terms" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content p-4">
            
            <div class="modal-header border-0">
                <h3 class="fw-bold mb-0">Terms & Conditions</h3>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body text-start terms-overview mb-5">
                <h5 class="fw-bold mb-3">OVERVIEW</h5>
                <p class="mb-3">
                    Here's a hearty welcome big and warm enough  to encompass  you all  your presence makes us happy and  
                    It's our pleasure extend a cheerful welcome  to you all at Himrishtey.com. It is a site Make a perfect match 
                    and Bond of togetherness among to  beautiful  person. This is an agreement purely legal binding  terms terms 
                    for your membership. This agreement can be modified from time to time and it may be affected by simple notice 
                    to members. All records are maintained by computer system And need not any physical or  digital signature. 
                    Any e suggestions regarding the improvement of the site is always welcome.
                </p>

                <h5 class="fw-bold mb-2">Conditions and Terms</h5>
                <p>Conditions and terms  use of Him Rishtey platform.</p>

                <p>It's mandatory to use this site only By those who are  Eligible for marriage as per the law motu.</p>
                <p>this site is not meant for promoting illicit  or sexual relation Any illicit relationship.</p>
                <p>Himrishtey.com has full right to terminate  any member membership if found in any illicit  relationship without any refund.</p>
                <p>You may leave your membership at any time by  informing himrishtey.com. in writing.</p>
                <p>If you Terminate your membership you will not be  eligible  for any refund.</p>
                <p>Himrishtey.com  is fully entitled to terminate your membership for any  breach of agreement.</p>
                <p>actionsite  is meant only for personal use only for subscriber the contents of site may not be used for any commercial activities.</p>
                <p>Appropriate legal action will be taken against any illegal and unauthorised use of the site.</p>
                <p>Himrishtey site have all proprietary rights copyrights material trademark and other proprietary information.</p>
                <p>Site may delete any content messages photos profiles which is not required for any purpose .</p>
                <p>Any vulgar content will not be authorised and strict  action will be taken against defaulter.</p>
                <p class="mb-3">Subscriber of the site sole responsible for the content, messages, photos or any material display or share by him or her.</p>

                <h5 class="fw-bold mb-2">Acceptance of the End User License Agreement  (EULA)</h5>
                <p> By using the Himrishtey site , you acknowledge that you have read,understood , and agree to the End User License Agreement (EULA).The EULA governs the licensing of ths App to you and details your rights to use the site on your device. </p>
          
          
            </div>
            
        </div>
    </div>
</div>
