<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="{{ asset('assets/img/favicon.ico') }}" type="image/x-icon" />
    <title>Him Rishtey | Marriage Bureau in Palampur Himachal Pradesh</title>
    <meta name="description"
        content="Him Rishtey is most trusted Indian matrimony site. Marriage Bureau in Palampur Himachal Pradesh" />
    <meta name="author" content="index.html" />
    <meta name="keywords" content="Him Rishtey, Marriage Bureau in Palampur, Marriage Bureau in Himachal Pradesh" />
    <meta name="robots" content="index, follow">
    <!-- Icon css link -->
    <link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/stroke-icon/style.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/flat-icon/flaticon.css') }}" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Rev slider css -->
    <link href="{{ asset('assets/vendors/revolution/css/settings.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/revolution/css/layers.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/revolution/css/navigation.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/animate-css/animate.css') }}" rel="stylesheet">

    <!-- Extra plugin css -->
    <link href="{{ asset('assets/vendors/magnify-popup/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/owl-carousel/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/bootstrap-selector/bootstrap-select.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendors/lightbox/simpleLightbox.css') }}" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('assets/bundles/slimcropper/css/slim.min.css') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/bundles/confirm/css/jquery-confirm.css') }}" />

    <link rel="stylesheet" href="{{ asset('assets/bundles/xdsoft/css/jquery.datetimepicker.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/bundles/timepicker/mdtimepicker.min.css') }}">

    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/tab.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/bundles/cropimage/croppie.css') }}">

    <link rel="stylesheet" href="{{ asset('assets/bundles/izitoast/css/iziToast.min.css') }}">

    <link rel="stylesheet" href="{{ asset('assets/bundles/select2/dist/css/select2.min.css') }}">

    <!--link rel="stylesheet" type="text/css" href="bundles/masonry/css/default.css" /-->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/bundles/masonry/css/component.css') }}" />

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/bundles/fancybox/jquery.fancybox.min.css') }}" />


    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300&amp;display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Kadwa&amp;display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Pacifico&amp;display=swap" rel="stylesheet">

    <script src="{{ asset('assets/js/jquery-2.2.4.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/bundles/izitoast/js/iziToast.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/bundles/confirm/js/jquery-confirm.js') }}"></script>

    <script src="{{ asset('assets/bundles/masonry/js/modernizr.custom.js') }}"></script>
    <script src="{{ asset('assets/bundles/masonry/js/masonry.pkgd.min.js') }}"></script>
    <script src="{{ asset('assets/bundles/masonry/js/imagesloaded.js') }}"></script>
    <script src="{{ asset('assets/bundles/masonry/js/classie.js') }}"></script>
    <script src="{{ asset('assets/bundles/masonry/js/AnimOnScroll.js') }}"></script>

    <script src="{{ asset('assets/js/custom.js') }}"></script>

    <!-- Chosen -->

    <link rel="stylesheet" href="{{ asset('assets/bundles/chosen/prism.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/bundles/chosen/chosen.css') }}">

    <link rel="stylesheet" href="{{ asset('assets/bundles/multiselectcb/css/jquery.multiselect.css') }}">

    <script src="{{ asset('assets/bundles/multiselectcb/js/jquery.multiselect.js') }}"></script>


    <script src="{{ asset('assets/bundles/slimcropper/js/slim.kickstart.min.js') }}"></script>

</head>

<body>

    <!--================Header Area =================-->
    <header class="main_header_area white_menu">
        <div class="header_top_mobile">

            <div>
                <div style="display:inline-block;margin-left: 15px;"><i class="fa fa-phone"></i> +91 9857102002</div>
                <div style="display:inline-block;float: right;margin-right: 15px;"><i class="fa fa-envelope-o"></i>
                    himrishtey@gmail.com</div>
            </div>
            <ul class="header_social" style="margin-left: 15px;">
                <li><a href="https://facebook.com/himrishtey"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://twitter.com/himrishte"><i class="fa fa-twitter"></i></a></li>
                <li><a href="https://www.instagram.com/himrishtey/"><i class="fa fa-instagram"></i></a></li>
                <li><a href="https://youtube.com/channel/UCwIe3GhJL-_c0bQ80eFv6RQ"><i class="fa fa-youtube"></i></a>
                </li>
            </ul>
            <div style="display: inline-block;margin-left: 15px;float: right;margin-right: 15px;">
                <ul class="header_social">
                    <li><a class="header-mobile-btn" href="{{ route('welcome') }}#registration-form">Register</a></li>
                    <li><a class="header-mobile-btn" href="{{ route('login') }}">Login</a></li>
                </ul>

            </div>

        </div>
        <div class="header_top">
            <div class="container">
                <div class="header_top_inner">
                    <div class="pull-left">
                        <a href="#"><i class="fa fa-phone"></i>+91 9459170004</a>
                        <a href="#"><i class="fa fa-envelope-o"></i>rishteyhirishte@gmail.com</a>
                        <ul class="header_social">
                            <li><a href="https://facebook.com/himrishtey"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/himrishte"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/himrishtey/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://youtube.com/channel/UCwIe3GhJL-_c0bQ80eFv6RQ"><i
                                        class="fa fa-youtube"></i></a></li>
                        </ul>
                    </div>
                    <div style="margin-top: 8px" class="pull-right">

                    <ul class="header_social">
                            @if(Auth::guard('member')->check())
                                <li>
                                    <a href="{{ route('member-logout') }}"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"></i> Logout
                                    </a>
                                    <form id="logout-form" action="{{ route('member-logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </li>
                            @else
                                <li><a href="{{ route('login') }}"><i class="fa fa-sign-in"></i> Login</a></li>
                            @endif
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        <div class="header_menu">
            <nav class="navbar navbar-default">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand logo" href="{{ route('welcome') }}">
                            <img src="{{ asset('assets/img/logo.png') }}" alt="">
                            <img src="{{ asset('assets/img/logo.png') }}" alt="">
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="{{ route('welcome') }}">Home</a>
                            </li>
                            <li>
                                <a href="{{ route('success-stories') }}">Success Stories</a>

                            </li>
                            <li>
                                <a href="{{ route('about-us') }}">About Us</a>

                            </li>
                            <li>
                                <a href="{{ route('contact-us') }}">Contact Us</a>

                            </li>

                        </ul>
                        <ul class="nav navbar-nav navbar-right">

                            <li class="book_btn">
                                <a class="book_now_btn" href="{{ route('welcome') }}#registration-form">Register</a>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        </div>
    </header>
    @yield('content')
    <!--================Footer Area =================-->
    <footer class="footer_area">
        <div class="footer_widget_area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-xs-6">
                        <aside class="f_widget about_widget">
                            <div class="f_title">
                                <h3>Location</h3>
                            </div>
                            <div class="ab_wd_list">
                                <div class="media">
                                    <div class="media-left">
                                        <i class="fa fa-map-marker"></i>
                                    </div>
                                    <div class="media-body">
                                        <h4><a href="https://g.co/kgs/aXh6Nu" target="_blank">1st floor, Manali, Mandi -
                                                Pathankot Rd,<br> opp. Palam hardware Kalu ki Hatti, Palampur,
                                                <br>Himachal Pradesh 176061</a></h4>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-left">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="media-body">
                                        <h4><a href="tel:+91 9459170004" style="color:white">+91 9459170004</a></h4>
                                    </div>
                                </div>
                            </div>

                        </aside>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <aside class="f_widget link_widget">
                            <div class="f_title">
                                <h3>Policy</h3>
                            </div>
                            <ul>
                                <li><a href="{{ route('refund-policy') }}">- Refund Policy</a></li>
                                <li><a href="{{ route('privacy-policy') }}">- Privacy Policy</a></li>
                                <li><a href="{{ route('terms-and-conditions') }}">- Terms & Conditions</a></li>
                                <li><a href="{{ route('child-safety-standard') }}">- Child Safety Standard</a></li>
                            </ul>
                        </aside>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <aside class="f_widget link_widget">
                            <div class="f_title">
                                <h3>Extra Link</h3>
                            </div>
                            <ul>
                                <li><a href="#" data-toggle="modal" data-target="#advertise_with_us">- Advertise with
                                        us</a></li>
                                <li><a href="{{ route('pricing') }}">- Payment Plans</a></li>
                                <li><a href="{{ route('about-us') }}">- About Us</a></li>
                            </ul>
                        </aside>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <aside class="f_widget instagram_widget">
                            <div class="f_title">
                                <h3>Download App</h3>
                            </div>
                            <ul class="instagram_list" id="instafeed">
                                <li><a href="https://play.google.com/store/apps/details?id=com.app.himrishtey"><img
                                            src="{{ asset('assets/img/playstore.png') }}"></a></li>
                            </ul>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <div class="search_area zoom-anim-dialog mfp-hide" id="test-search">
        <div class="search_box_inner">
            <h3>Search</h3>
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><i class="icon icon-Search"></i></button>
                </span>
            </div>
        </div>
    </div>


    <!-- Rev slider js -->
    <script src="{{ asset('assets/vendors/revolution/js/jquery.themepunch.tools.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/revolution/js/jquery.themepunch.revolution.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/revolution/js/extensions/revolution.extension.video.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/revolution/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/revolution/js/extensions/revolution.extension.navigation.min.js') }}"></script>

    <script src="{{ asset('assets/vendors/magnify-popup/jquery.magnific-popup.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/isotope/imagesloaded.pkgd.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/isotope/isotope.pkgd.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/counterup/waypoints.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/counterup/jquery.counterup.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/owl-carousel/owl.carousel.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.js') }}"></script>
    <script src="{{ asset('assets/bundles/xdsoft/js/jquery.datetimepicker.full.js') }}"></script>
    <script src="{{ asset('assets/vendors/bootstrap-selector/bootstrap-select.js') }}"></script>
    <script src="{{ asset('assets/vendors/lightbox/simpleLightbox.min.js') }}"></script>

    <script src="{{ asset('assets/bundles/timepicker/mdtimepicker.js') }}"></script>
    <script src="{{ asset('assets/bundles/cropimage/croppie.js') }}"></script>
    <script src="{{ asset('assets/bundles/select2/dist/js/select2.full.min.js') }}"></script>

    <script src="{{ asset('assets/js/bootstrap-tabcollapse.js') }}"></script>

    <script src="{{ asset('assets/js/theme.js') }}"></script>
    <script src="{{ asset('assets/bundles/chosen/chosen.jquery.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/bundles/chosen/prism.js') }}" type="text/javascript" charset="utf-8"></script>
    <script src="{{ asset('assets/bundles/chosen/init.js') }}" type="text/javascript" charset="utf-8"></script>

    <script src="{{ asset('assets/bundles/fancybox/jquery.fancybox.min.js') }}" type="text/javascript"></script>



    <script type="text/javascript">
    $('#mytabs').tabCollapse();
    </script>

    <!-- The modal -->
    <div class="modal fade" id="advertise_with_us" tabindex="-1" role="dialog" aria-labelledby="modalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="modalLabel">Advertise With Us</h4>
                </div>
                <div class="modal-body">
                    <form action="#" method="post">
                        <input type="hidden" name="save_awu" value="Yes" />
                        <div class="pe-field">
                            <label>Advertise Name</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <input type="text" class="form-control fc-sm" id="advertise_name" name="advertise_name"
                                value="" required="">
                        </div>
                        <div class="pe-field">
                            <label>Advertise Link</label>
                            <input type="text" class="form-control fc-sm" id="advertise_link" name="advertise_link"
                                value="">
                        </div>
                        <div class="pe-field">
                            <label>Contact Person</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <input type="text" class="form-control fc-sm" id="contact_person" name="contact_person"
                                value="" required="">
                        </div>
                        <div class="pe-field">
                            <label>Mobile Number</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <input type="number" class="form-control fc-sm" id="mobile_number" name="mobile_number"
                                value="" required="">
                        </div>
                        <div class="pe-field">
                            <label>E Mail</label><span class="req-star"><sup><i class="fa fa-star"></i></sup></span>
                            <input type="text" class="form-control fc-sm" id="email" name="email" value="" required="">
                        </div>
                        <div class="">
                            <label>About Ad</label><span class="req-star"><sup><i class="fa fa-star"></i></sup></span>
                            <textarea class="form-control" id="about_ad" name="about_ad"></textarea>
                        </div>

                        <div class="center col-md-12">
                            <button type="submit" class="mbutton mbc2">Save</button>
                        </div>

                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div id="privacy_policy" class="modal fade" role="dialog">
        <div class="modal-dialog big-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Privacy Policy</h4>
                </div>
                <div class="modal-body">
                    <p><span id="docs-internal-guid-4f4f5655-7fff-9beb-785b-5093379fdf11"><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Your
                                    privacy is important to us, and so it is transparent about how we collect, use and
                                    share information about you. The purpose of this policy is to help you
                                    understand:-</span></p><br><br>
                            <p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">What
                                    information do we collect from you? And where do you use it-</span></p>
                            <p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">We
                                    provide matrimony service through HimRishtey.com&nbsp; so we ask for certain
                                    personal information which is displayed on the site on your behalf to find the right
                                    life partner. You consent through our term and condition to collect, process and
                                    share your personal information in order to provide the service. Himrishtey.com when
                                    you are availing our services</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">&nbsp;Collects
                                    two types of information:-</span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">information
                                    that you give to us</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">and
                                    other information that is given to us by someone else (parents etc.).</span></p><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">In
                                    order to avail the service, you provide the following information:-</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">When
                                    registering for our service, you share your personal data with us, such as name,
                                    your gender, date of birth, contact details, educational qualifications, employment
                                    details, photos, marital status and your interests and sensitive personal data such
                                    as health Data, community etcâ€¦. In this sequence, only a few fields are mandatory
                                    for the user / member, the rest some fields are optional, whether to fill the
                                    information in them or not, it is up to the user. The User/Member is solely
                                    responsible for maintaining the confidentiality of the Username/Identity and User
                                    Password and for all activities and transmissions/transactions.</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">&nbsp;</span>
                            </p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">How
                                    do we use the information we collect?</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">We
                                    use the collected information in the following ways:</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">We
                                    create your profile that is visible to other users (male to female, male to female)
                                    from the information you submit to provide the service.</span></p><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Managing
                                    your account</span></p><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">You
                                    are given full access to manage your account You can change your information at any
                                    time with our approval</span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">With
                                    whom does we share your information?</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Except
                                    where you are expressly informed on the site or as described in this privacy policy
                                    we do not sell, rent, share, trade or give away any of your personal
                                    information.</span></p><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">with
                                    other users</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">We
                                    publish&nbsp; as a profile the information you share with other users in order to
                                    provide the Services. The information thus published is provided by you and be
                                    careful what you share with other users. You can always control your photo privacy
                                    settings by going to the Photo Privacy Options in Settings page.</span></p><br>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">With
                                    our service providers and partners</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">We
                                    may use third party service providers to provide website and application
                                    development, hosting, maintenance, backup, storage, payment processing, analysis and
                                    other services for us, which may require them to access or use information about
                                    you.&nbsp; If a service provider needs to access information about you to perform
                                    services on our behalf, they do so under close instruction from us, including
                                    policies and procedures designed to protect your information. All of our service
                                    providers and partners agree to strict confidentiality obligations. but still
                                    disclaims any and all responsibility or liability for the accuracy, content,
                                    completeness, legality, reliability, or operability or availability of information
                                    or materials displayed on this web site by third parties ...</span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;"><br><br></span>
                            </p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">With
                                    law enforcement agencies</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">we
                                    will disclose your personally identifiable information as required by law and when
                                    we believe that disclosure is necessary to protect our rights, other members
                                    interest and protection and/or comply with a judicial proceeding, court order, or
                                    legal process served on our Web site.</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span><span
                                    style="font-size: 16pt; font-family: Arial; color: rgb(32, 33, 36); background-color: rgb(248, 249, 250); font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">himrishtey.com
                                    is not responsible for any kind of cyber fraud. If someone contacts you and claims
                                    himself as our representative and asks for cash or bank transfer, be careful that we
                                    do not ask for such things. Our membership plans are done online only. If you are
                                    meeting any person with reference to this website, how you are treating him is
                                    solely your reaction.&nbsp;&nbsp;</span></p>
                            <p dir="ltr" style="line-height:1.542857142857143;margin-top:-1pt;margin-bottom:-1pt;"><br>
                            </p>
                        </span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div id="refund_policy" class="modal fade" role="dialog">
        <div class="modal-dialog big-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Refund Policy</h4>
                </div>
                <div class="modal-body">
                    <p>
                    <p>
                        <font color="#000000" face="Rubik, sans-serif"><span style="font-size: 16px;">himrishtey.com
                                believes in helping its community as far as possible !</span></font>
                    </p>
                    <p>
                        <font color="#000000" face="Rubik, sans-serif"><span style="font-size: 16px;"><br></span></font>
                    </p>
                    <p>
                        <font color="#000000" face="Rubik, sans-serif"><span style="font-size: 16px;">In the instance of
                                you chose to terminate your membership, the MEMBERSHIP FEES ARE NOT REFUNDABLE under any
                                circumstances.</span></font>
                    </p>
                    <p>
                        <font color="#000000" face="Rubik, sans-serif"><span style="font-size: 16px;"><br></span></font>
                    </p>
                    <p>
                        <font color="#000000" face="Rubik, sans-serif"><span style="font-size: 16px;">The membership
                                with himrishtey is for your personal use only and it is not transferable, and you may
                                not authorize others to use your membership, you may not assign or transfer your
                                membership to any person or entity.</span></font>
                    </p>
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6186161c6bb0760a4941606c/1fjpscoo7';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();

    </script>
    <!--End of Tawk.to Script-->

</body>

</html>