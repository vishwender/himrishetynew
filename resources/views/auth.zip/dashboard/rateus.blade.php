<div class="modal fade" id="rateUsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content p-4 rounded-3 shadow">
      <div class="modal-header border-0">
        <h5 class="modal-title fw-bold">Rate Us</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        
        <div class="mb-3" id="starDisplay">
          <span class="fs-3 text-muted">&#9733;</span>
          <span class="fs-3 text-muted">&#9733;</span>
          <span class="fs-3 text-muted">&#9733;</span>
          <span class="fs-3 text-muted">&#9733;</span>
          <span class="fs-3 text-muted">&#9733;</span>
        </div>

        <input type="range" id="ratingSlider" min="0" max="5" step="0.1" value="0" class="form-range">
        <p class="mt-2">Rating: <span id="ratingValueText">0.0</span></p>
        <input type="hidden" id="ratingValue" name="rating">

        <div class="mb-3">
          <textarea class="form-control" id="ratingText" rows="3" placeholder="Write your feedback..."></textarea>
        </div>
      </div>
      <div class="modal-footer border-0 justify-content-center">
        <button type="button" class="btn btn-info px-4 text-white" id="submitRating">Submit</button>
      </div>
    </div>
  </div>
</div>

<script>
    //Star rating
$(document).ready(function () {
  $("#ratingSlider").on("input", function () {
    let value = parseFloat($(this).val()).toFixed(1);
    $("#ratingValue").val(value);
    $("#ratingValueText").text(value);
    let fullStars = Math.floor(value);
    let decimal = value - fullStars;

    $("#starDisplay span").removeClass("text-warning").addClass("text-muted");

    $("#starDisplay span").each(function (index) {
      if (index < fullStars) {
        $(this).addClass("text-warning").removeClass("text-muted");
      } else if (index === fullStars && decimal > 0) {
        $(this).addClass("text-warning").removeClass("text-muted");
      }
    });
  });

  $("#submitRating").on("click", function () {
    let stars = $("#ratingValue").val();
    let feedback = $("#ratingText").val();

    if (!stars || stars == 0) {
      Swal.fire({
        icon: "warning",
        title: "Oops...",
        text: "Please select a star rating!"
      });
      return;
    }

    $.ajax({
      url: "{{ route('user-rate') }}",
      method: "POST",
      data: {
        _token: "{{ csrf_token() }}",
        stars: stars,
        feedback: feedback
      },
      success: function (response) {
        Swal.fire({
          icon: "success",
          title: "Thank you!",
          text: response.message,
          timer: 2000,
          showConfirmButton: false
        });

        $("#rateUsModal").modal("hide");
        $("#ratingText").val("");
        $("#ratingValue").val("");
        $("#ratingSlider").val(0);
        $("#ratingValueText").text("0.0");
        $("#starDisplay span").removeClass("text-warning").addClass("text-muted");
      },
      error: function () {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Something went wrong. Please try again."
        });
      }
    });
  });
});
    </script>
