@extends('dashboard.layouts.app')

@section('content')

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="white_box mb_30">
                <div class="box_header d-flex justify-content-between align-items-center">
                    <div class="main-title">
                        <h3 class="mb-0">Success Stories</h3>
                    </div>
                    <button class="btn btn-info text-white font-weight-semibold" data-bs-toggle="modal" data-bs-target="#addStoryModal">
                        + Add Story
                    </button>
                </div>
                <div class="row g-4 mt-3">
                    @foreach($success_stories as $stories)
                        <div class="col-md-4">
                            <div class="card shadow border-0 h-100">
                                <img src="{{ 'https://himrishtey.com/photos/ss/'.$stories->photo}}" class="card-img-top rounded-top" alt="Story 1">
                                <div class="card-body text-center">
                                    <h5 class="card-title">{{ $stories->groom_name . '-' . $stories->bride_name}}</h5>
                                    <p class="card-text text-muted">{{ $stories->detail }}</p>
                                    <div class="d-flex justify-content-center mt-3 gap-2">
                                        <button class="btn btn-sm btn-info text-white" data-bs-toggle="modal" data-bs-target="#editStoryModal{{ $stories->id }}">
                                            Edit
                                        </button>
                                        <form action="{{ route('stories_delete', $stories->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this story?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="editStoryModal{{ $stories->id }}" tabindex="-1" aria-labelledby="editStoryModalLabel{{ $stories->id }}" aria-hidden="true">
                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary text-white">
                                        <h5 class="modal-title text-white" id="editStoryModalLabel{{ $stories->id }}">Edit Story</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="{{ route('stories_update', $stories->id) }}" method="POST" enctype="multipart/form-data">
                                            @csrf
                                            @method('PUT')
                                            <div class="row g-3">
                                                <div class="col-md-8">
                                                    <label for="groom_name" class="form-label">Groom Name</label>
                                                    <input type="text" name="groom_name" class="form-control" value="{{ $stories->groom_name }}" required>
                                                </div>
                                                <div class="col-md-8">
                                                    <label for="bride_name" class="form-label">Bride Name</label>
                                                    <input type="text" name="bride_name" class="form-control" value="{{ $stories->bride_name }}" required>
                                                </div>
                                                <div class="col-md-8">
                                                    <label for="photo" class="form-label">Upload Image</label>
                                                    <input type="file" name="photo" class="form-control">
                                                    <small class="text-muted">Current Image: {{ $stories->photo }}</small>
                                                </div>
                                                <div class="col-md-8">
                                                    <label for="detail" class="form-label">Your Story</label>
                                                    <textarea name="detail" class="form-control" rows="4" required>{{ $stories->detail }}</textarea>
                                                </div>
                                            </div>
                                            <div class="mt-4 text-end">
                                                <button type="submit" class="btn btn-info px-4 text-white">Update Story</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addStoryModal" tabindex="-1" aria-labelledby="addStoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title text-white" id="addStoryModalLabel">Add your story</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('stories_store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label for="groom_name" class="form-label">Groom Name</label>
                            <input type="text" name="groom_name" class="form-control" placeholder="Enter Groom Name" required>
                        </div>
                        <div class="col-md-8">
                            <label for="bride_name" class="form-label">Bride Name</label>
                            <input type="text" name="bride_name" class="form-control" placeholder="Enter Bride Name" required>
                        </div>
                        <div class="col-md-8">
                            <label for="photo" class="form-label">Upload Image</label>
                            <input type="file" name="photo" class="form-control" required>
                        </div>
                        <div class="col-md-8">
                            <label for="detail" class="form-label">Your Story</label>
                            <textarea name="detail" class="form-control" rows="4" placeholder="Write your beautiful journey..." required></textarea>
                        </div>
                    </div>
                    <div class="mt-4 text-end">
                        <button type="submit" class="btn btn-info text-white px-4">Post Story</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
