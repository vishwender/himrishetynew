@extends('dashboard.layouts.app')
@section('content')
<div class="row">
    <div class="col-md-3">
        <div class="white_box mb_30">
            <div class="box_header ">
                <div class="main-title">
                     <h3 class="mb-0">Quick Search</h3>
                </div>
            </div>
            <form method="get" action="{{ route('quick-search') }}">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Age From</label>
                            <input type="number" class="form-control" name="partner_age_from" value="{{ $partnerAgeFrom ? $partnerAgeFrom : '' }}" id="exampleFormControlInput1" placeholder="18">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Age to</label>
                            <input type="number" class="form-control" value="{{ $partnerAgeTo ? $partnerAgeTo : '' }}" name="partner_age_to" id="exampleFormControlInput1" placeholder="26">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect1">Religion</label>
                    <select class="form-control" id="quick_religion"  name="partner_religion[]" multiple="multiple">
                        @foreach($data['religions'] as $religion)
                            <option value="{{ $religion->religion }}"
                                {{ is_array($partnerReligions) && in_array($religion->religion, $partnerReligions) ? 'selected' : '' }}>
                                {{ $religion->religion }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Community</label>
                    <select  class="form-control" name="partner_cast[]" id="quick_community" multiple="multiple">
                        @foreach($data['casts'] as $cast)
                        <option value="{{ $cast->cast }}"
                        {{ is_array($partnerCasts) && in_array($cast->cast, $partnerCasts) ? 'selected' : '' }} >
                        {{ $cast->cast }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Marital Status</label>
                    <select class="form-control" name="marital_status">
                        <option value="">Select Option</option>
                        @foreach($data['mstatus'] as $ms)
                        <option value="{{ $ms->marital_status }}" {{ $ms->marital_status == $maritalStatus ? 'selected' : '' }}>{{ $ms->marital_status }}</option>
                        @endforeach
                    </select>
                </div>
                <input type="submit" name="submit" class="btn btn-info mt-3 text-white" value="Search" />
            </form>
        </div>
    </div>
    <div class="col-md-9">
        <div class="row">
            @foreach($data['searchedMembers'] as $recent)
            <div class="col-md-4">
                <a href="javascript:void(0)" class="viewProfile" data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                    <div class="card mb-3 card-width">
                        <img class="card-img-top" src="{{ $recent['photo'] }}" height="380" alt="Card image cap">
                        <div class="product-detail">
                            <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                             <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} | {{ $recent['cast'] }}</span>
                            <blockquote>
                                <p>{{ $recent['religion'] }}</p>
                                <p>{{ $recent['education'] }}</p>
                                <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                            </blockquote>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach     
        </div>
    </div>
</div>
@endsection