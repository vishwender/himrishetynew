<div class="footer_part">

    <div class="container">

        <div class="row">

            <div class="col-lg-12">

                <div class="footer_iner text-center">

                    <p>2020 © Influence - Designed by <a href="#"> <i class="ti-heart"></i> </a><a href="#"> Gracious
                            Solutions</a></p>

                </div>

            </div>

        </div>

    </div>

</div>