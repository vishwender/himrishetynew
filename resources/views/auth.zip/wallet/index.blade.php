@extends('dashboard.layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="card p-5">
                <h3>My Wallet</h3>
                <p>Balance: <strong id="wallet_balance">{{ $wallet->wallet_balance ?? 0 }}</strong> credits</p>

                <form id="walletRechargeForm">
                    @csrf
                    <label>Enter Amount</label>
                    <input type="number" name="amount" class="form-control" min="10" required>
                    <button type="submit" class="btn btn-info text-white mt-3">Add Money</button>
                </form>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
$('#walletRechargeForm').submit(function(e){
    e.preventDefault();
    $.ajax({
        url: "{{ route('wallet.createOrder') }}",
        type: "POST",
        data: $(this).serialize(),
        success: function(data){
            var options = {
                "key": data.razor_key,
                "amount": data.amount,
                "currency": data.currency,
                "name": "Wallet Recharge",
                "order_id": data.order_id,
                handler: function (response){
                    $.post("{{ route('wallet.callback') }}", {
                        _token: '{{ csrf_token() }}',
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                        amount: data.amount
                    }, function(res){
                        if(res.balance !== undefined){
                            $('#wallet_balance').text(res.balance);
                        }
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: 'Wallet recharged successfully!',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            location.reload(); // ✅ refresh after OK
                        });
                    }).fail(function(){
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops!',
                            text: 'Payment verification failed.'
                        });
                    });
                }

            };
            var rzp1 = new Razorpay(options);
            rzp1.open();
        },
        error: function(xhr){
            alert("Something went wrong: " + xhr.responseText);
        }
    });
});
</script>
@endsection
