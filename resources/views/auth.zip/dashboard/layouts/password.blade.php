<!-- Password Change Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <div class="main-title">
                    <h3 class="mb-0">Change Password</h3>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="changePasswordForm">
                    @csrf
                    <div class="mb-3">
                        <label>Current Password</label>
                        <input type="password" name="current_password" class="form-control">
                        <span class="text-danger error-text current_password_error"></span>
                    </div>
                    <div class="mb-3">
                        <label>New Password</label>
                        <input type="password" name="new_password" class="form-control">
                        <span class="text-danger error-text new_password_error"></span>
                    </div>
                    <div class="mb-3">
                        <label>Confirm Password</label>
                        <input type="password" name="new_password_confirmation" class="form-control">
                        <span class="text-danger error-text new_password_confirmation_error"></span>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>

            </div>
        </div>
    </div>
</div>
<script>
$(document).on('submit', '#changePasswordForm', function(e) {
    e.preventDefault();

    $(".error-text").text(""); // clear old errors

    $.ajax({
        url: "{{ route('update-password') }}",
        method: "POST",
        data: $(this).serialize(),
        success: function(res) {
            if(res.success){
                alert(res.message);
                $('#changePasswordModal').modal('hide');
                $('#changePasswordForm')[0].reset();
            }
        },
        error: function(err) {
            if (err.status === 422) {
                let errors = err.responseJSON.errors;
                $.each(errors, function (key, value) {
                    $("."+key+"_error").text(value[0]);
                });
            }
        }
    });
});
</script>