@extends('layouts.app')

@section('content')

<section class="banner_area">
    <div class="container">
        <div class="banner_inner_content">
            <h3>Ours Plan</h3>
            <ul>
                <li class="active"><a href="{{ route('welcome') }}">Home</a></li>
                <li><a href="#">Upgrade Plan</a></li>
            </ul>
        </div>
    </div>
</section>
<section class="page-area">
    <div class="container">
        <div class="explor_title row m0">
            <div class="center_ex_title">
                <h2>Our <span>Plan</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="membership-plans">
                    @foreach($pricings as $pricing)
                    <div class="columns">
                        <ul class="price">
                            <li class="offer">
                                <div><img class="special-offer-img" src="{{ asset('assets/img/offer1.gif') }}" /></div>
                                <div></div>
                            </li>
                            <li class="header">{{ $pricing['plan_name'] }}</li>
                            <li class="grey"><i class='fa fa-inr' aria-hidden='true'></i> {{ $pricing['final_cost'] }} <span
                                    Style="text-decoration: line-through;"><i class="fa fa-inr" aria-hidden="true"></i>
                                    {{ $pricing['plan_cost'] }}</span></li>
                            <li><i class="fa fa-check plan-yes-ico" aria-hidden="true"></i> <b>Duration Days:</b> {{ $pricing['duration_days'] }}
                            </li>
                           <li><i class="fa fa-check plan-yes-ico" aria-hidden="true"></i> <b>View Contact: </b>{{ $pricing['view_contact'] }}</li>
                            <li><i class="fa fa-check plan-yes-ico" aria-hidden="true"></i> <b>View Profile:</b> {{ $pricing['view_profile'] }}
                            </li>
                            <li><i class="fa fa-times plan-no-ico" aria-hidden="true"></i> <b>Personal Message:</b>
                            </li>
                        </ul>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
@endsection