@extends('dashboard.layouts.app')

@section('content')

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-lg border-0 text-center">
                <div class="card-header bg-success text-white">
                    <h3 class="mb-0">Payment Successful </h3>
                </div>

                <div class="card-body">
                    <h4>Thank you, {{ auth()->guard('member')->user()->full_name }}!</h4>

                    <p class="lead">Your payment was successful and your membership has been activated.</p>

                    <a href="#" class="btn btn-primary mt-3">
                        Home
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

@endsection
