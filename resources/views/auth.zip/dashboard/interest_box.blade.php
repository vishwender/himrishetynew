@extends('dashboard.layouts.app')
@section('content')
<div class="row">
    <div class="col-lg-12">
        <div class="white_box mb_30">
            <div class="box_header ">
                <div class="main-title">
                    <h3 class="mb-0">Interests</h3>
                </div>
            </div>
            <div class="container" id="interest_box">
                {{-- Main Tabs --}}
                <ul class="nav nav-pills mb-3 border-bottom border-2" id="interest-main-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link text-primary fw-semibold active position-relative" id="received-tab"
                            data-bs-toggle="pill" data-bs-target="#received" type="button" role="tab"
                            aria-controls="received" aria-selected="true">
                            Received
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link text-primary fw-semibold position-relative" id="sent-tab"
                            data-bs-toggle="pill" data-bs-target="#sent" type="button" role="tab" aria-controls="sent"
                            aria-selected="false">
                            Sent
                        </button>
                    </li>
                </ul>

                <div class="tab-content border rounded-3 border-primary p-3 text-danger" id="interest-main-tabContent">
                    {{-- Received Tab --}}
                    <div class="tab-pane fade show active" id="received" role="tabpanel" aria-labelledby="received-tab">
                        <ul class="nav nav-pills mb-3 border-bottom border-2" id="received-sub-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold active position-relative"
                                    id="received-pending-tab" data-bs-toggle="pill" data-bs-target="#received-pending"
                                    type="button" role="tab" aria-controls="received-pending" aria-selected="true">
                                    Pending Interests
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold position-relative"
                                    id="received-accepted-tab" data-bs-toggle="pill" data-bs-target="#received-accepted"
                                    type="button" role="tab" aria-controls="received-accepted" aria-selected="false">
                                    Accepted Interests
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold position-relative"
                                    id="received-rejected-tab" data-bs-toggle="pill" data-bs-target="#received-rejected"
                                    type="button" role="tab" aria-controls="received-rejected" aria-selected="false">
                                    Rejected Interests
                                </button>
                            </li>
                        </ul>

                        <div class="tab-content" id="received-sub-tabContent">
                            <div class="tab-pane fade show active" id="received-pending" role="tabpanel"
                                aria-labelledby="received-pending-tab">
                                <div class="row">
                                    @foreach($data['received_pending_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id  }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="tab-pane fade" id="received-accepted" role="tabpanel"
                                aria-labelledby="received-accepted-tab">
                                <div class="row">
                                    @foreach($data['received_accepted_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id  }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="tab-pane fade" id="received-rejected" role="tabpanel"
                                aria-labelledby="received-rejected-tab">
                                <div class="row">
                                    @foreach($data['received_rejected_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id  }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Sent Tab --}}
                    <div class="tab-pane fade" id="sent" role="tabpanel" aria-labelledby="sent-tab">
                        <ul class="nav nav-pills mb-3 border-bottom border-2" id="sent-sub-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold active position-relative"
                                    id="sent-pending-tab" data-bs-toggle="pill" data-bs-target="#sent-pending"
                                    type="button" role="tab" aria-controls="sent-pending" aria-selected="true">
                                    Pending Interests
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold position-relative"
                                    id="sent-accepted-tab" data-bs-toggle="pill" data-bs-target="#sent-accepted"
                                    type="button" role="tab" aria-controls="sent-accepted" aria-selected="false">
                                    Accepted Interests
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link text-primary fw-semibold position-relative"
                                    id="sent-rejected-tab" data-bs-toggle="pill" data-bs-target="#sent-rejected"
                                    type="button" role="tab" aria-controls="sent-rejected" aria-selected="false">
                                    Rejected Interests
                                </button>
                            </li>
                        </ul>

                        <div class="tab-content" id="sent-sub-tabContent">
                            <div class="tab-pane fade show active" id="sent-pending" role="tabpanel"
                                aria-labelledby="sent-pending-tab">
                                <div class="row">
                                    @foreach($data['sent_pending_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id  }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sent-accepted" role="tabpanel"
                                aria-labelledby="sent-accepted-tab">
                                <div class="row">
                                    @foreach($data['sent_accepted_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id  }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sent-rejected" role="tabpanel"
                                aria-labelledby="sent-rejected-tab">
                                <div class="row">
                                    @foreach($data['sent_rejected_interests'] as $rcp)
                                    <div class="col-md-4">
                                        <a href="javascript:void(0)" class="viewProfile"
                                            data-url="{{ route('view-profile', ['id' => $rcp->id]) }}"
                                            data-id="{{ $rcp->id }}">
                                            <div class="card mb-3 card-width">
                                                <img class="card-img-top" src="{{ $rcp->photo }}" height="380"
                                                    alt="Card image cap">
                                                <div class="product-detail">
                                                    <h5 class="card-title heading text-center">{{ $rcp->full_name }}</h5>
                                                    <span class="subheading">{{ $rcp->age_years }} yr | {{ $rcp->height }}
                                                        |
                                                        {{ $rcp->cast }}</span>
                                                    <blockquote>
                                                        <p>{{ $rcp->religion }}</p>
                                                        <p>{{ $rcp->education }}</p>
                                                        <p>{{ $rcp->city_living_in . ', ' . $rcp->state_living_in }}</p>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div> {{-- end main tab content --}}
            </div>
        </div>
    </div>
</div>
@endsection