@extends('dashboard.layouts.app')
@section('content')
<style>
    .card-header{
        background-color: #022e5b;
    }
   
    </style>
<div class="row">
    <div class="col-lg-8 mb-3">
        <div class="white_box mb-3 d-flex justify-content-between">
            <div class="card h-100 w-100 profile-section">
                <img src="{{ $profile->photo }}" class="card-img-top" id="mainImage" alt="Profile Image" style="height: 300px; object-fit: cover;">
                <div class="card-body d-flex flex-column justify-content-between">
                    <div>
                        <h6 class="card-text">{{ $profile->full_name }} | {{ $profile->profile_id }}</h6>
                        <p class="card-text">{{ $profile->age_years }} | {{ $profile->height }} ft</p>
                        <p class="card-text">Profile created {{ $profile->profile_created_for }} | {{ $profile->age_years }} years </p>
                        <p class="card-text">Profile Id - {{ $profile->profile_id }} | {{ $profile->religion }} | {{ $profile->cast}} |  {{ $profile->city_living_in }}</p>
                       <p class="card-text"><i class="ti-location-pin"></i> {{ $profile->city_living_in }}, {{ $profile->state_living_in }}</p>
                    </div>
                </div>
            </div>
            @if(!empty($profilegallery))
            <div class="gallery">
                @foreach($profilegallery as $profileimg)
                    <div class="gallery-item">
                        <img src="{{ 'https://himrishtey.com/photos/photo_gallery/' . $profileimg->photo }}" alt="Gallery Image">
                    </div>
                @endforeach
            </div>
            @else
            <div class="gallery">
                <div class="gallery-item">
                        <h6>No gallery found</h6>
                    </div>
            </div>
            @endif
        </div>
        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-#022e5b text-white">
                    Basic Details
                </div>
                <div class="card-body">
                    <p>Profile created for {{ $profile->profile_created_for }} | {{ $profile->age_years }} years</p>
                    <p>Profile ID: {{ $profile->profile_id }} | {{ $profile->religion }} | {{ $profile->cast }} | {{ $profile->city_living_in }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">
                    Astro & Kundali Details
                </div>
                <div class="card-body">
                    <p>Date of Birth: {{ \Carbon\Carbon::parse($profile->birth_date_time)->toDateString() }}</p>
                    <p>Time of Birth: {{ \Carbon\Carbon::parse($profile->birth_date_time)->format('h:i A') }}</p>
                    <p>Place of Birth: {{ $profile->birth_place }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">
                    Religion Information
                </div>
                <div class="card-body">
                    <p>Community: {{ $profile->cast }}</p>
                    <p>Sub Community: {{ $profile->sub_cast }}</p>
                    <p>Gotra: {{ $profile->gotra }}</p>
                    <p>Native Place: {{ $profile->birth_place }}</p>
                    <p>Mother Tongue: {{ $profile->mother_tongue }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">
                    Contact Information
                </div>
                <div class="card-body">
                    <p>Contact Number: {{ $profile->mobile_number }}</p>
                    <p>Whatsapp: {{ $profile->whatsapp_number }}</p>
                    <p>Email: {{ $profile->email }}</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">Family Details</div>
                <div class="card-body">
                    <p>Family Type: {{ $profile->family_type }}</p>
                    <p>Father Occupation: {{ $profile->father_occupation }}</p>
                    <p>Mother Occupation: {{ $profile->mother_occupation }}</p>
                    <p>Brothers: {{ $profile->no_of_brothers }}</p>
                    <p>Married Brothers: {{ $profile->married_brothers }}</p>
                    <p>Sisters: {{ $profile->no_of_sisters }}</p>
                    <p>Married Sisters: {{ $profile->married_sisters }}</p>
                    <p>Native Place: {{ $profile->native_place }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">Lifestyle</div>
                <div class="card-body">
                    <p>Diet: {{ $profile->diet }}</p>
                    <p>Smoking: {{ $profile->is_smoking }}</p>
                    <p>Drinking: {{ $profile->is_drinking }}</p>
                    <p>Any Disability: {{ $profile->any_disability }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">Partner Preferences</div>
                <div class="card-body">
                    <p>Height: {{ $profile->partner_height_from }} - {{ $profile->partner_height_to }}</p>
                    <p>Age: {{ $profile->partner_age_from }} - {{ $profile->partner_age_to }}</p>
                    <p>Marital Status: {{ $profile->looking_for }}</p>
                    <p>Religion & Mother Tongue: {{ $profile->partner_religion }}</p>
                    <p>Community: {{ $profile->partner_cast }}</p>
                    <p>Is Manglik: {{ $profile->is_partner_manglik }}</p>
                    <p>Education: {{ $profile->partner_education }}</p>
                    <p>Occupation: {{ $profile->partner_occupation }}</p>
                    <p>Annual Income: {{ $profile->partner_annual_income_from }} - {{ $profile->partner_annual_income_to }}</p>
                </div>
            </div>
        </div>

        <div class="white_box mb-3">
            <div class="card">
                <div class="card-header bg-purple text-white">About</div>
                <div class="card-body">
                    <p>{{ $profile->about_me }}</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
  jQuery(document).ready(function($){
        $(".gallery img").click(function(){
            let newSrc = $(this).attr("src");
            $("#mainImage").fadeOut(200, function(){
                $(this).attr("src", newSrc).fadeIn(200);
            });
        });
    })
</script>
@endsection
