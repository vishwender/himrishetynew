<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Himrishtey com</title>
        <link rel="icon" href="{{ asset('assets/user/img/logo.png') }}" type="image/png">
        <link rel="stylesheet" href="{{ asset('assets/user/css/bootstrap1.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/themefy_icon/themify-icons.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/swiper_slider/css/swiper.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/select2/css/select2.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/niceselect/css/nice-select.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/owl_carousel/css/owl.carousel.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/gijgo/gijgo.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/font_awesome/css/all.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/tagsinput/tagsinput.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/datatable/css/jquery.dataTables.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/datatable/css/responsive.dataTables.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/datatable/css/buttons.dataTables.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/text_editor/summernote-bs4.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/morris/morris.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/user/vendors/material_icon/material-icons.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/css/metisMenu.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/user/css/style1.css') }}" />
        <link rel="stylesheet" href="{{ asset('assets/user/css/colors/default.css') }}" id="colorSkinCSS">
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="{{ asset('assets/user/js/jquery1-3.4.1.min.js') }} "></script> 
    </head>

    <body class="crm_body_bg">
        @include('dashboard.includes.sidebar')
        <section class="main_content dashboard_part">
            @include('dashboard.includes.header')
            <div class="main_content_iner ">
                <div class="container-fluid p-0">
                    <div id="memberModal"></div>
                    <div id="planMyModal"></div>
                    <div id="profileModal"></div>
                    <div id="viewAllModal"></div>
                    @yield('content')
                </div>
            </div>
            @include('dashboard.layouts.password')
            @include('dashboard.includes.footer')

        </section>

        <script src="{{ asset('assets/user/js/popper1.min.js') }} "></script>
        <script src="{{ asset('assets/user/js/bootstrap1.min.js') }} "></script>
        <script src="{{ asset('assets/user/js/metisMenu.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/count_up/jquery.waypoints.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/chartlist/Chart.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/count_up/jquery.counterup.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/swiper_slider/js/swiper.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/niceselect/js/jquery.nice-select.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/owl_carousel/js/owl.carousel.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/gijgo/gijgo.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/jquery.dataTables.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/dataTables.responsive.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/dataTables.buttons.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/buttons.flash.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/jszip.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/pdfmake.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/vfs_fonts.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/buttons.html5.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/datatable/js/buttons.print.min.js') }} "></script>
        <script src="{{ asset('assets/user/js/chart.min.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/progressbar/jquery.barfiller.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/tagsinput/tagsinput.js') }} "></script>
        <script src="{{ asset('assets/user/vendors/text_editor/summernote-bs4.js') }} "></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="{{ asset('assets/user/js/custom.js') }} "></script>

        <script>
            navigator.serviceWorker.register('{{asset("sw.js")}}').then(reg => {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        reg.pushManager.subscribe({
                            userVisibleOnly: true,
                            applicationServerKey: 'BKPn9U9gHfYd3qRCwq4TuRsJFOuj4kyycB6Qh8IUBFYzs19uF-oitF9-64-ShnMYTu0PRq6TJcv3wQ1G2fyzMT4'
                        }).then(subscription => {
                            fetch('{{ url("/save-subscription") }}', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                },
                                body: JSON.stringify(subscription)
                            });
                        });
                    }
                });
            });
        </script>
    </body>
</html>