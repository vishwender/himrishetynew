@extends('dashboard.layouts.app')
@section('content')
<div class="row">
    <div class="col-md-3">
        <div class="white_box mb_30">
            <div class="box_header ">
                <div class="main-title">
                     <h3 class="mb-0">Advance Search</h3>
                </div>
            </div>
            <form id="advanceSearchForm" method="get" action="{{ route('advance-search') }}">
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlInput1">Profile ID</label>
                    <input type="text" class="form-control" name="profile_id" id="exampleFormControlInput1" placeholder="HIM00000">
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Age From</label>
                            <input type="number" class="form-control" name="partner_age_from" value="{{ $partnerAgeFrom ? $partnerAgeFrom : '' }}" id="exampleFormControlInput1" placeholder="18">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Age to</label>
                            <input type="number" class="form-control" value="{{ $partnerAgeTo ? $partnerAgeTo : '' }}" name="partner_age_to" id="exampleFormControlInput1" placeholder="26">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Height From</label>
                            <select class="form-control" name="partner_height_from">
                                <option value=""></option>
                                @foreach($data['heights'] as $height)
                                    <option value="{{ $height->height }}">
                                        {{ $height->height }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Height to</label>
                            <select class="form-control" name="partner_height_to">
                                <option value=""></option>
                                @foreach($data['heights'] as $height)
                                    <option value="{{ $height->height }}">
                                        {{ $height->height }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect1">States</label>
                    <select class="form-control" id="advance_state"  name="partner_states[]" multiple="multiple">
                        @foreach($data['states'] as $state)
                            <option value="{{ $state->name }}">
                                {{ $state->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect1">Religion</label>
                    <select class="form-control" id="quick_religion"  name="partner_religion[]" multiple="multiple">
                        @foreach($data['religions'] as $religion)
                            <option value="{{ $religion->religion }}"
                                {{ is_array($partnerReligions) && in_array($religion->religion, $partnerReligions) ? 'selected' : '' }}>
                                {{ $religion->religion }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect1">Manglik</label>
                    <select class="form-control" id="manglik" name="partner_manglik">
                        <option value=""></option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Community</label>
                    <select  class="form-control" name="partner_cast[]" id="quick_community" multiple="multiple">
                        @foreach($data['casts'] as $cast)
                        <option value="{{ $cast->cast }}"
                        {{ is_array($partnerCasts) && in_array($cast->cast, $partnerCasts) ? 'selected' : '' }} >
                        {{ $cast->cast }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Annual Income From (lpa)</label>
                            <select class="form-control" name="partner_annual_income_from">
                                <option value=""></option>
                                @for($i = 0; $i <= 50; $i++)
                                <option value="{{ $i }}">{{ $i }}</option>
                                @endfor
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                        <label class="form-label" for="exampleFormControlInput1">Annual Income To (lpa)</label>
                            <select class="form-control" name="partner_annual_income_to">
                                <option value=""></option>
                                @for($i = 0; $i <= 50; $i++)
                                <option value="{{ $i }}">{{ $i }}</option>
                                @endfor
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Mother Tongue</label>
                    <select  class="form-control" name="partner_mother_tongue[]" id="quick_mother_tongue" multiple="multiple">
                        @foreach($data['mother_tongues'] as $mt)
                        <option value="{{ $mt->mother_tongue }}" >
                        {{  $mt->mother_tongue }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Education</label>
                    <select class="form-control" name="partner_education[]" id="quick_education" multiple="multiple">
                        @foreach($data['educations'] as $education)
                        <option value="{{ $education->education }}" >{{ $education->education }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Employed In</label>
                    <select class="form-control" name="partner_employers" id="quick_employers" multiple="multiple">
                        @foreach($data['employers'] as $employer)
                        <option value="{{ $employer->employer }}" >{{ $employer->employer }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="exampleFormControlSelect2">Marital Status</label>
                    <select class="form-control" name="marital_status">
                        <option value=""></option>
                        @foreach($data['mstatus'] as $ms)
                        <option value="{{ $ms->marital_status }}" {{ $ms->marital_status == $maritalStatus ? 'selected' : '' }}>{{ $ms->marital_status }}</option>
                        @endforeach
                    </select>
                </div>
                <input type="submit" name="submit " class="btn btn-info mt-3 text-white" value="Search" />
            </form>
        </div>
    </div>
    <div class="col-md-9">
        <div id="searchResults">
                
        </div>
    </div>
</div>
<script>
$(document).ready(function () {
    // Trigger AJAX on typing or selecting
    $('#advanceSearchForm').find('input, select, textarea').on('input change keyup', function () {
        let form = $('#advanceSearchForm');
        let formData = form.serialize();

        $.ajax({
            url: form.attr('action'),
            method: "GET",
            data: formData,
            beforeSend: function() {
                $('#searchResults').html('<p class="text-center">🔄 Loading...</p>');
            },
            success: function (response) {
                $('#searchResults').html(response);
            },
            error: function (xhr) {
                console.error("Error:", xhr.responseText);
                $('#searchResults').html('<p class="text-danger text-center">⚠ Something went wrong.</p>');
            }
        });
    });

    // Prevent full page reload on form submit
    $('#advanceSearchForm').on('submit', function (e) {
        e.preventDefault();
        $(this).find('input:first').trigger('keyup'); 
    });
});
</script>
@endsection