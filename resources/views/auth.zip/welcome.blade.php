@extends('layouts.app')
@section('content')
<div class="marquee">
    <marquee> Welcome to Himachals No1 Matrimonial website HimRishtey.com</marquee>
</div>
<!--================Slider Area =================-->
<section class="main_slider_area">

    <div id="main_slider3" class="rev_slider" data-version="5.3.1.6">
        <ul>
            <li data-index="rs-1587" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"
                data-thumb="img/home-slider/slider-5.jpg" data-rotate="0" data-saveperformance="off"
                data-title="Creative" data-param1="01" data-param2="" data-param3="" data-param4="" data-param5=""
                data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                <img src="{{ asset('assets/img/home-slider/slide1.jpg') }}" alt="" data-bgposition="center center"
                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

            </li>
            <li data-index="rs-1588" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"
                data-thumb="img/home-slider/slider-6.jpg" data-rotate="0" data-saveperformance="off"
                data-title="Creative" data-param1="01" data-param2="" data-param3="" data-param4="" data-param5=""
                data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                <img src="{{ asset('assets/img/home-slider/slide2.jpg') }}" alt="" data-bgposition="center center"
                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>
            </li>
            <li data-index="rs-1589" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"
                data-thumb="img/home-slider/slider-7.jpg" data-rotate="0" data-saveperformance="off"
                data-title="Creative" data-param1="01" data-param2="" data-param3="" data-param4="" data-param5=""
                data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                <img src="{{ asset('assets/img/home-slider/slide3.jpg') }}" alt="" data-bgposition="center center"
                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

            </li>
            <li data-index="rs-1587" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"
                data-thumb="img/home-slider/slider-5.jpg" data-rotate="0" data-saveperformance="off"
                data-title="Creative" data-param1="01" data-param2="" data-param3="" data-param4="" data-param5=""
                data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                <img src="{{ asset('assets/img/home-slider/slide4.jpg') }}" alt="" data-bgposition="center center"
                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

            </li>
        </ul>
    </div>
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
    <div style="display:none1;" class="book_room_area">
        <div class="container">
            <form id="iForm" action="{{ route('initial-register') }}" method="POST">
                <div class="book_room_box">
                    <div class="book_table_item">
                        <h3>Register</h3>
                    </div>
                    @csrf
                    <div class="book_table_item">
                        <div class="input-append">
                            <select name="profile_created_for" id="profile_created_for" required>
                                <option disabled selected>PROFILE CREATED FOR</option>
                                @foreach($data['profileCreatedFor'] as $pcf)
                                <option value="{{ $pcf['value'] }}">{{ $pcf['title'] }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append">
                            <input name="full_name" id="full_name" type="text" value="" placeholder="Full Name"
                                maxlength="20" required>
                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append">
                            <input name="email" id="email" type="text" value="" placeholder="Email" required>
                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append">
                            <!--<input name="mobile_number" id="mobile_number" type="tel" minlength="10" maxlength="10" placeholder="Mobile Number" required onkeyup="check(); return false;">-->
                            <input type="number" id="mobile_number" name="mobile_number" pattern="/^-?\d+\.?\d*$/"
                                onKeyPress="if(this.value.length==10) return false;" placeholder="Mobile Number"
                                required />
                            <span id="message"></span>
                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append">
                            <select name="gender" id="gender" required>
                                <option disabled selected>GENDER</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append">
                            <input name="password" id="password" type="text" value="" placeholder="Create Password"
                                required>
                        </div>
                    </div>

                    <div id="mems1error" class="book_table_item center">
                        <span>Please enter required fields</span>
                    </div>

                    <div class="book_table_item center">
                        <button type="button" onclick="checkMemberExist();" class="homepage_register_btn"
                            >Register Now</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="book_table_area">
        <div class="container">
        <form method="get" action="{{ route('search-home-member') }}" id="search-home-member">
                <div class="book_table_inner row m0">
                    <div class="book_table_item">
                        <div class="input-append aleft">
                            <label>My search is for</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <select id="partner_gender" name="partner_gender" class="form-control" required>
                                <option></option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>

                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append aleft">
                            <label>Marital Status</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <select class="form-control" id="marital_status" name="marital_status" required>
                                <option></option>
                                @foreach($data['mstatus'] as $row)
                                <option value="{{ $row['marital_status'] }}">{{ $row['marital_status'] }}</option>
                                @endforeach
                            </select>

                        </div>
                    </div>
                    <div class="book_table_item">
                        <div class="input-append aleft">
                            <label>Age between (From)</label><span class="req-star"><sup><i
                                        class="fa fa-star"></i></sup></span>
                            <select id="partner_age_from" name="partner_age_from" class="form-control" required>
                                <option></option>
                                @for($ai=18;$ai<=50;$ai++)
                                <option value="{{ $ai }}">{{ $ai }} Years</option>
                                @endfor
                            </select>
                        </div>
                    </div>

                    <div class="book_table_item">
                        <div class="input-append aleft">
                            <label>To</label>
                            <select id="partner_age_to" name="partner_age_to" class="form-control" required>
                                <option></option>
                                @for($ai=18;$ai<=50;$ai++)
                                <option value="{{ $ai }}">{{ $ai }} Years</option>
                                @endfor
                            </select>
                        </div>
                    </div>

                    <div class="book_table_item">

                        <button class="book_now_btn" type="submit">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!--================End Slider Area =================-->
<section class="choose_resot_area">
    <div class="container">
        <div class="center_title">
            <h2>Success <span>Stories</span></h2>
            <p>Better we were alone, best we are together</p>
        </div>
        <div class="row explor_room_item_inner">
            @foreach($data['stories'] as $story)
            <div class="col-md-4 col-sm-6">
                <div class="explor_item">
                    <a href="#" class="room_image">
                        <img src="https://himrishtey.com/photos/ss/{{ $story['photo'] }}" alt="">
                    </a>
                    <div class="explor_text">
                        <a href="#">
                            <h5 class="ss-weds">{{ $story['groom_name'] }} <i class="fa fa-heart" aria-hidden="true"></i> {{ $story['bride_name']}}</h5>
                        </a>
                        <p>{{ $story['detail'] }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<!--================Specification Resort Area =================-->
<section class="spec_resort_area">
    <div class="container">
        <div class="main_big_title">
            <h2>About <span>HimRishtey</span></h2>
            <p>HimRishtey is one of the best matrimonial / marriage bureau websites in Himachal Pradesh. we connect
                hearts not relationships. Today, we are the most trusted Matrimony / Marriage Bureau website by Brand
                Trust Report. Millions of happy marriages happened and continue to happen through HimRishtey. We also
                have a strong offline presence across India with all Himachal pradesh like Kangra, Una, hamirpur,
                Shimla, Manali etc. HimRishtey is the 1st group to offer 100% mobile verified profiles, reinforcing the
                trust that members have on us. We have also pioneered the highly personalized matchmaking services -
                Assisted Service and EliteMatrimony. Our purpose is to build a better Himachal through happy marriages.
            </p>
        </div>

    </div>
</section>


<section class="our_resort_gallery_area">
    <div class="middle_title">
        <h2>Groom</h2>
    </div>
    <div class="groom_gallery_inner imageGallery1">
        <div class="groom_gallery owl-carousel">
            @foreach($data['grooms'] as $groom)
            <div class="item">
                <div class="profile_item brides">
                    <a href="#" class="room_image">
                        <img src="{{ $groom['photo'] }}" alt="" />
                    </a>
                    <div class="member_meta">
                        <span class="mm_member_name">{{ $groom['name'] }}</span>
                        <span class="mm_member_om">{{ $groom['age'] }} Years / {{ $groom['height'] }} {{ $groom['religion']}}</span>
                        <span class="mm_member_om">{{ $groom['cast'] }}</span>
                        <span class="mm_member_om"> {{ $groom['education'] }}</span>
                        <span class="mm_member_om">{{ $groom['city']}} {{ $groom['state'] }}</span>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<section class="our_resort_gallery_area">
    <div class="middle_title">
        <h2><span>Bride</span></h2>
    </div>
    <div class="resort_gallery_inner imageGallery1">
        <div class="resort_gallery owl-carousel">
        @foreach($data['brides'] as $groom)
            <div class="item">
                <div class="profile_item brides">
                    <a href="#" class="room_image">
                        <img src="{{ $groom['photo'] }}" alt="" />
                    </a>
                    <div class="member_meta">
                        <span class="mm_member_name">{{ $groom['name'] }}</span>
                        <span class="mm_member_om">{{ $groom['age'] }} Years / {{ $groom['height'] }} {{ $groom['religion']}}</span>
                        <span class="mm_member_om">{{ $groom['cast'] }}</span>
                        <span class="mm_member_om"> {{ $groom['education'] }}</span>
                        <span class="mm_member_om">{{ $groom['city']}} {{ $groom['state'] }}</span>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>



<section class="our_service_area">
    <div class="container">
        <div class="row our_service_inner">
            <div class="col-md-3 col-sm-6">
                <div class="our_service_item">
                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                    <h4>Success Story</h4>
                    <p>Hundred’s of successful member found their soulmates with us.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="our_service_item">
                    <i class="fa fa-user-o" aria-hidden="true"></i>
                    <h4>Verified Members</h4>
                    <p>Thousands of verified member profile so our members find perfect partner without any concern.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="our_service_item">
                    <i class="fa fa-search" aria-hidden="true"></i>
                    <h4>Search Options</h4>
                    <p>Multiple search options to find partner who know you better.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="our_service_item">
                    <i class="fa fa-address-book-o" aria-hidden="true"></i>
                    <h4>Matching Profiles</h4>
                    <p>With our auto match profile you can see members which was suits you best and get married.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="choose_resot_area">
    <div class="container">
        <div class="center_title">
            <h2>Why choose <span>HimRishtey</span></h2>
            <p>Reasons why you will find the PERFECT match on himrishtey.com</p>
        </div>
        <div class="row choose_resot_inner">
            <div class="col-md-8">
                <div class="resot_list">
                    <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Trusted by millions of happy
                                customers</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>'Pocket Friendly' membership
                                plans</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Organise Interactive
                                get-togethers, wedding festivals and marriage counselling</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Mission -To build a
                                prosperous nation through successful marriages</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>In the match-making business
                                since the past 38 years!</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>The perfect blend of
                                traditional process & advanced technology</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Pioneers in research on
                                Maharashtrian wedding industry</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Genuine & verified
                                profiles</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <img class="home-couple w100" src="{{ asset('assets/img/couple-home.jpg') }}" />
            </div>
        </div>
    </div>
</section>

<script>
function check() {

    var mobile = document.getElementById('mobile_number');


    var message = document.getElementById('message');

    var goodColor = "#0C6";
    var badColor = "#FF9B37";

    if (mobile.value.length != 10) {

        mobile.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "required 10 digits, match requested format!"
    }
}

function checkMemberExist() {
    var full_name = $("#full_name").val();
    var email = $("#email").val();
    var mobile_number = $("#mobile_number").val();
    var password = $("#password").val();
    if (full_name == '') {
        $("#mems1error span").html('Please enter your name');
        $("#mems1error").show();
        $("#full_name").focus();
        return false;
    }
    if (!validEmail(email)) {
        $("#mems1error span").html('Please enter valid email');
        $("#mems1error").show();
        $("#email").focus();
        return false;
    }
    if (mobile_number == '') {
        $("#mems1error span").html('Please enter your mobile number');
        $("#mems1error").show();
        $("#mobile_number").focus();
        return false;
    }
    if (password == '') {
        $("#mems1error span").html('Please enter password');
        $("#mems1error").show();
        $("#password").focus();
        return false;
    }

    $.ajax({
        url: "{{ route('checkMemberExist') }}",
        type: "POST",
        data: {
            email: email,
            mobile_number: mobile_number,
             _token: $('#iForm input[name="_token"]').val(), 
        },
        datatype: 'html',
        success: function(nor) {
            if(parseInt(nor) == 1){
                $("#mems1error span").html('EMail id already exist');
                $("#mems1error").show();
                $("#email").focus();
                return false;
            }
            if (parseInt(nor) == 2) {
                $("#mems1error span").html('Mobile Number already exist');
                $("#mems1error").show();
                $("#mobile_number").focus();
                return false;
            }
            if (parseInt(nor) == 0) {

                $("#iForm").submit();
            }
        }
    });
}
</script>
@endsection