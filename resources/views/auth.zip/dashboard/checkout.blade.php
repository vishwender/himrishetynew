@extends('dashboard.layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0">{{ $plan->plan_name }} Plan</h4>
                </div>
                <div class="card-body text-center">
                    <h5 class="mb-3">₹{{ $plan->final_cost }}</h5>
                    <p><strong>Duration:</strong> {{ $plan->duration_days }} days</p>
                    <p><strong>View Contacts:</strong> {{ $plan->view_contact }}</p>
                    <p><strong>View Profiles:</strong> {{ $plan->view_profile }}</p>

                    <button id="rzp-button" class="btn btn-success btn-lg mt-3">
                        Pay ₹{{ $plan->final_cost }}
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.getElementById('rzp-button').onclick = function(e){
    var options = {
        "key": "{{ $razor_key }}", 
        "amount": "{{ $plan->final_cost * 100 }}",
        "currency": "INR",
        "name": "Matrimony Website",
        "description": "{{ $plan->plan_name }} Membership",
        "order_id": "{{ $order_id }}", 
        "handler": function (response){
                    var form = document.createElement('form');
                    form.method = "POST";
                    form.action = "{{ route('membership.verify') }}";

                    var token = document.createElement('input');
                    token.type = "hidden";
                    token.name = "_token";
                    token.value = "{{ csrf_token() }}";
                    form.appendChild(token);

                    var orderId = document.createElement('input');
                    orderId.type = "hidden";
                    orderId.name = "razorpay_order_id";
                    orderId.value = response.razorpay_order_id;
                    form.appendChild(orderId);

                    var paymentId = document.createElement('input');
                    paymentId.type = "hidden";
                    paymentId.name = "razorpay_payment_id";
                    paymentId.value = response.razorpay_payment_id;
                    form.appendChild(paymentId);

                    var signature = document.createElement('input');
                    signature.type = "hidden";
                    signature.name = "razorpay_signature";
                    signature.value = response.razorpay_signature;
                    form.appendChild(signature);

                    var planId = document.createElement('input');
                    planId.type = "hidden";
                    planId.name = "plan_id";
                    planId.value = "{{ $plan->id }}";
                    form.appendChild(planId);

                    document.body.appendChild(form);
                    form.submit();
                },

        "prefill": {
            "name": "{{ Auth::user()->name }}",
            "email": "{{ Auth::user()->email }}",
            "contact": "{{ Auth::user()->phone }}"
        },
        "theme": {
            "color": "#6A0DAD"
        }
    };
    var rzp1 = new Razorpay(options);
    rzp1.open();
    e.preventDefault();
}
</script>
@endsection
