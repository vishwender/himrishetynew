@extends('dashboard.layouts.app')
@section('content')
<div class="row">
    <div class="col-md-3">
        <div class="white_box mb_30">
            <div class="box_header ">
                <div class="main-title">
                     <h3 class="mb-0">Quick Search</h3>
                </div>
            </div>
            <form method="get" action="{{ route('search-by-profile-id') }}">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label class="form-label" for="exampleFormControlInput1">Profile Id</label>
                            <input type="text" class="form-control" name="profile_id" value="{{ $profile_id ? $profile_id : '' }}" id="exampleFormControlInput1" placeholder="HIM0000">
                        </div>
                    </div>
                </div>
                <button class="btn btn-info mt-3 text-white"><i class="ti-search"></i> Search </button>
            </form>
        </div>
    </div>
    @if(!empty($profile))
    <div class="col-md-9">
        <div class="row">
            <div class="col-md-6">
                <a href="javascript:void(0)" class="viewProfile" data-url="{{ route('view-profile', ['id' => $profile['id']]) }}" data-id="{{ $profile['id'] }}">
                    <div class="card mb-3 card-width">
                        <img class="card-img-top" src="{{ $profile['photo'] }}" height="380" alt="Card image cap">
                        <div class="product-detail">
                            <h5 class="card-title heading text-center">{{ $profile['full_name'] }}</h5>
                            <span class="subheading">{{ $profile['age_years'] }} years | {{ $profile['height'] }} | {{ $profile['cast'] }}</span>
                            <blockquote>
                                <p>{{ $profile['religion'] }}</p>
                                <p>{{ $profile['education'] }}</p>
                                <p>{{ $profile['city_living_in'] . ', ' . $profile['state_living_in'] }}</p>
                            </blockquote>
                        </div>
                    </div>
                </a>
            </div>   
        </div>
    </div>
    @endif
</div>
@endsection