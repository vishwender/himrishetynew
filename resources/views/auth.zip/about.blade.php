@extends('layouts.app')

@section('content')

<section class="introduction_area resort_story_area">
    <div class="container">
        <div class="row introduction_inner">
            <div class="col-md-5">
                <a href="#" class="introduction_img">
                    <img src="{{ asset('assets/img/about-us.jpg') }}" alt="">
                </a>
            </div>
            <div class="col-md-7">
                <div class="introduction_left_text">
                    <div class="resort_title">
                        <h2>About <span>Us</span></h2>
                    </div>
                    <p>{!! $aboutUs !!}</p>
                </div>
            </div>
        </div>
        <div class="center">
            <a class="about_btn_b" href="{{ route('contact-us') }}">contact us</a>
        </div>

    </div>

</section>

@endsection