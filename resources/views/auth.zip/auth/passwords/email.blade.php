@extends('layouts.app')

@section('content')
<style>
.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    height: auto;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0, 0, 0, .125);
    border-radius: .375rem;
}

.card-header {
    padding: .5rem 1rem;
    margin-bottom: 0;
    background-color: rgba(0, 0, 0, .03);
    border-bottom: 1px solid rgba(0, 0, 0, .125);
    font-weight: 500;
}

.card-body {
    flex: 1 1 auto;
    padding: 1rem 1rem;
}

.card-footer {
    padding: .5rem 1rem;
    background-color: rgba(0, 0, 0, .03);
    border-top: 1px solid rgba(0, 0, 0, .125);
}

.mt-3 {
    margin-top: 3rem !important;
}

.mb-3 {
    margin-bottom: 3rem !important;
}

#cont {
    margin-top: 180px;
}
.nav-tabs {
  border-bottom: none;
  margin-bottom: 15px;
}
.nav .nav-item{
  width: 50%;
  /* border: 1px solid #ccc; */
  margin-bottom: 2px;
}
.nav .nav-item.active a{
 background:#fe372b;
 color: #fff;
 border-radius: 4px;
 text-align: center;
}
.nav-tabs>li>a {
  margin-right: 2px;
  line-height: 1.42857143;
  border: 1px solid #dad8d8;
  border-radius: 4px;
  text-align: center;
    background-color: #022e5b;
}
.nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover {
  cursor: default;
  background-color: #fff;
  border-radius: 4px;
  color:#022e5b;
  border:2px solid #fe372b;
}
.nav-tabs>li>a:focus, .nav-tabs>li>a:hover {
  color: #022e5b;
  cursor: default;
  background-color: #fff;
  border-radius: 4px;
  border:2px solid #022e5b;
}
.nav-item:not(:last-child) {
  padding-right: 1rem;
}
.d-flex{
    display:flex;
}
</style>
<div class="container" id="cont">
    <div class="rest-heading">
        <div class="resort_title">
            <h2>Reset <span>Password</span></h2>
        </div>
    </div>
    <div class="row ">
        <div class="col-md-8">
            <div class="tab-content">
                <ul class="nav nav-tabs d-flex" role="tablist">
                    <li class="nav-item active">
                        <a href="#home" role="tab" data-toggle="tab">
                            {{ __('Reset Password Using Registered Email Address') }}
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#profile" role="tab" data-toggle="tab">
                            {{ __('Reset Password using registered Phone Number') }}
                        </a>
                    </li>
                </ul>
                <div class="tab-pane fade active in" id="home">
                    <form method="POST" action="{{ route('member.password.email') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="email"
                                class="col-md-12 col-form-label text-md-end">{{ __('Enter Registered Email') }}</label>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                                    name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Send Password Reset Link') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="profile">
                    <div id="otp-alert"></div>
                    <form id="send-otp-form">
                        @csrf
                        <div class="row mb-3">
                            <label for="email"
                                class="col-md-12 col-form-label text-md-end">{{ __('Enter Registered Phone') }}</label>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <input id="phone" type="text" class="form-control @error('phone') is-invalid @enderror"
                                    name="phone" value="{{ old('phone') }}" required autocomplete="email" autofocus>
                                @error('phone')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Send OTP') }}
                                </button>
                            </div>
                        </div>
                    </form>
                    <form id="verify-otp-form" style="display:none">
                        @csrf
                        <div class="row mb-3">
                            <label for="email"
                                class="col-md-12 col-form-label text-md-end">{{ __('Reset your Password with OTP verification') }}</label>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <input id="otp" type="text" class="form-control @error('otp') is-invalid @enderror"
                                    name="otp" value="{{ old('otp') }}" required autocomplete="email" autofocus placeholder="Enter OTP">
                                @error('otp')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                                <div style="margin:10px 0px"></div>
                                <input id="password" type="text" class="form-control @error('password') is-invalid @enderror"
                                    name="password" value="{{ old('password') }}" required autocomplete="password" autofocus placeholder="Enter New Password">
                                @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="mb-3">
                <img src="https://himrishtey.com/update/assets/img/about-us.jpg">
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#send-otp-form').submit(function(e) {
        e.preventDefault(); // crucial to prevent page refresh
        $(this).find('button').attr('disabled',true);
        $.ajax({
            url: "{{ route('send-otp') }}",
            type: "POST",
            data: {
                phone: $('#phone').val(),
                _token: $('input[name="_token"]').val()
            },
            success: function(res) {
                $('#send-otp-form').remove();
                $('#otp-alert').html('<div class="alert alert-success">' + res.message +
                    '</div>');
                $('#verify-otp-form').css('display','');

            },
            error: function(xhr) {
                $('#otp-alert').html('<div class="alert alert-danger">' + xhr.responseJSON
                    .message + '</div>');
            }
        });
    });
});

$(document).ready(function() {
    $('#verify-otp-form').submit(function(e) {
        e.preventDefault(); // crucial to prevent page refresh
        $(this).find('button').attr('disabled',true);
        $.ajax({
            url: "{{ route('verify-otp') }}",
            type: "POST",
            data: {
                otp: $('#otp').val(),
                password: $('#password').val(),
                _token: $('input[name="_token"]').val()
            },
            success: function(res) {
                $('#otp-alert').html('<div class="alert alert-success">' + res.message +
                    '</div>');
                $('#verify-otp-form').css('display','');

            },
            error: function(xhr) {
                $('#otp-alert').html('<div class="alert alert-danger">' + xhr.responseJSON
                    .message + '</div>');
            }
        });
    });
});
</script>
@endsection