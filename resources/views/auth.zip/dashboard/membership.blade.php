<div class="modal" id="membership">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Memberships</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row justify-content-center">
                    @foreach($data['memberships'] as $membership)
                    <div class="col-md-12">
                        <div class="white_box mb_30">
                            <div class="box_header ">
                                <div class="main-title">
                                    <h3 class="mb-1" >{{ $membership['plan_name']}}</h3>
                                    <p>{{ \Illuminate\Support\Str::limit($membership['plan_description'], 180, '...') }}</p>
                                    <a href="#" id="plan" data-url="{{ route('plans', ['id' => $membership['id']]) }}"   class="btn btn-info mt-1 text-white">View more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <hr>
                <div class="container-fluid p-0">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <div class="white_box mb_30">
                                <div class="box_header ">
                                    <div class="main-title">
                                        <h3 class="mb-"1 >Need a Discussion?</h3>
                                        <a href="#" class="btn btn-danger" id="callback">Request a Callback</a>
                                        <h4 class="mt-3" id="clock"><b><i class="ti-timer"></i> 00:00 </b></h4>
                                        <h4 id="timer"></h4>
                                        <p>Need a Discussion, press the button above and we will contact you within 10 minutes</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
    <script>
        $(document).ready(function () {
            $(document).on('click', '#callback', function (e) {
                e.preventDefault();
                var button = $(this); // store button reference
                var user = "{{ auth()->guard('member')->user()->id }}";
                $.ajax({
                    url: "{{ route('callback') }}", 
                    type: "POST",
                    data: {
                        user_id: user,
                        _token: "{{ csrf_token() }}"
                    },
                    success: function (response) {
                        console.log("Success:", response);
                        if (typeof response === "string") {
                            try {
                                response = JSON.parse(response);
                            } catch (e) {
                                console.error("JSON parse error:", e);
                            }
                        }
                        if (response.Status === "OK") {
                            button.text('Please wait for a moment');
                            $('#clock').addClass('d-none');
                            button.attr('disabled','true');
                            var endTime = new Date().getTime() + (10 * 60 * 1000);
                            localStorage.setItem("callback_endTime", endTime);

                            startTimer("#timer");
                        } else {
                            console.log("Not OK:", response);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error("Error:", error);
                        console.log(xhr.responseText);
                    }
                });
            });
            if (localStorage.getItem("callback_endTime")) {
                startTimer("#timer");
            }

            function startTimer(displaySelector) {
                var display = $(displaySelector);
                var interval = setInterval(function () {
                    var now = new Date().getTime();
                    var endTime = localStorage.getItem("callback_endTime");
                    if (!endTime) {
                        clearInterval(interval);
                        return;
                    }
                    var distance = endTime - now;
                    if (distance <= 0) {
                        clearInterval(interval);
                        localStorage.removeItem("callback_endTime");
                        $('#callback').text('Request a Callback');
                        $('#clock').removeClass('d-none');
                        $('#callback').attr('disabled','false');
                    } else {
                        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                        minutes = minutes < 10 ? "0" + minutes : minutes;
                        seconds = seconds < 10 ? "0" + seconds : seconds;
                        display.text(minutes + ":" + seconds);
                    }
                }, 1000);
            }
        });


    </script>