<div class="container-fluid g-0">
    <div class="row">
        <div class="col-lg-12 p-0">
            <div class="header_iner d-flex justify-content-between align-items-center">
                <div class="sidebar_icon d-lg-none">
                    <i class="ti-menu"></i>
                </div>
                <div class="serach_field-area">
                    <div class="search_inner">

                    </div>
                </div>
                <div class="header_right d-flex justify-content-between align-items-center">
                    <div class="profile_info">
                        @if(auth()->guard('member')->user()->photo)
                        <img src="https://himrishtey.com/photos/photo/{{auth()->guard('member')->user()->photo }}" alt="#">
                        @else
                            @if(auth()->guard('member')->user()->gender == 'Male')
                            <img src="https://himrishtey.com/img/boy.jpg" alt="#">
                            @else
                            <img src="https://himrishtey.com/img/girl.jpg" alt="#">
                            @endif
                        @endif
                        <div class="profile_info_iner">
                            <div class="profile_info_details">
                                <ul>
                                    <li><a href="{{route('profile')}}"><span><i class="ti-user"></i></span> My Profile </a></li>
                                    @php
                                    $wallet = \App\Models\MemberWallet::where('member_id', auth()->guard('member')->user()->id)->latest('created_at')->first();
                                    @endphp
                                    <li><a href="{{route('wallet.index')}}"><span><i class="ti-wallet"></i></span> Wallet : {{ $wallet ? $wallet->wallet_balance : 0 }} </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>