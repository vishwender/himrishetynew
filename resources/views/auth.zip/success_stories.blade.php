@extends('layouts.app')

@section('content')

<section class="banner_area">
    <div class="container">
        <div class="banner_inner_content">
            <h3>Success Stories</h3>
            <ul>
                <li class="active"><a href="{{ route('welcome') }}">Home</a></li>
                <li><a href="#">Success Stories</a></li>
            </ul>
        </div>
    </div>
</section>
<section class="explor_room_area explore_room_list">
    <div class="container">
        <div class="explor_title row m0">
            <div class="left_ex_title">
                <h2>Success <span>Stories</span></h2>
            </div>
        </div>
        <div class="row explor_room_item_inner">
            @foreach($stories as $story)
            <div class="col-md-4 col-sm-6">
                <div class="explor_item">
                    <a href="#" class="room_image">
                        <img src="https://himrishtey.com/photos/ss/{{ $story['photo'] }}" alt="">
                    </a>
                    <div class="explor_text">
                        <a href="#">
                             <h5 class="ss-weds">{{ $story['groom_name'] }} <i class="fa fa-heart" aria-hidden="true"></i> {{ $story['bride_name']}}</h5>
                        </a>
                       <p>{{ $story['detail'] }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

@endsection