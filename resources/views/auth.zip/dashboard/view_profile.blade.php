
<style>
   /* ---------------- Modern Profile Modal ---------------- */
.profile-modal .modal-content {
    border-radius: 25px;
    background: #1b1b1f;
    color: #f0f0f0;
    font-family: 'Poppins', sans-serif;
    overflow: hidden;
    box-shadow: 0 25px 50px rgba(0,0,0,0.7);
}

/* Header */
.profile-modal .modal-header {
    background: #2c2c2e;
    border-bottom: none;
    border-radius: 25px 25px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    padding: 1rem 2rem;
    box-shadow: inset 0 -2px 5px rgba(255,255,255,0.05);
}

.profile-modal .modal-header h4 {
    font-weight: 700;
    font-size: 1.6rem;
    color: #ff6a61;
}

/* Badge / Action Buttons */
.profile-actions .badge {
    border-radius: 50px;
    font-weight: 600;
    padding: 0.5rem 1.2rem;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(.25,.8,.25,1);
    box-shadow: 3px 3px 8px rgba(0,0,0,0.2), -3px -3px 8px rgba(255,255,255,0.05);
}

.profile-actions .badge:hover {
    transform: scale(1.1) rotate(-2deg);
}

/* Main Profile Image */
.profile-section img#mainImage {
    width: 100%;
    border-radius: 20px;
    object-fit: cover;
    max-height: 350px;
    transition: transform 0.4s ease, box-shadow 0.4s ease;
    box-shadow: 8px 8px 20px rgba(0,0,0,0.5), -8px -8px 20px rgba(255,255,255,0.1);
}

.profile-section img#mainImage:hover {
    transform: scale(1.05) rotate(-1deg);
}

/* Gallery */
.gallery-item img {
    border-radius: 15px;
    cursor: pointer;
    transition: transform 0.35s ease, box-shadow 0.35s ease, rotate 0.35s ease;
    box-shadow: 4px 4px 12px rgba(0,0,0,0.4), -4px -4px 12px rgba(255,255,255,0.05);
}

.gallery-item img:hover {
    transform: scale(1.12) rotate(3deg);
    box-shadow: 6px 6px 18px rgba(0,0,0,0.6), -6px -6px 18px rgba(255,255,255,0.1);
}

/* Info Cards */
.card {
    background: #2a2a2c2b;;
    border-radius: 20px;
    border: none;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 8px 8px 20px rgba(0,0,0,0.6), -8px -8px 20px rgba(255,255,255,0.05);
    transition: transform 0.4s ease, box-shadow 0.4s ease;
}

.card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 12px 12px 30px rgba(0,0,0,0.7), -12px -12px 30px rgba(255,255,255,0.08);
}

.card-header {
    font-weight: 700;
    font-size: 1.05rem;
    margin-bottom: 0.8rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background-color:rgb(184 183 183 / 3%);
}

/* Card Body */
.card-body p {
    margin: 0.3rem 0;
    font-size: 0.95rem;
    color: #030303ff;
}

/* Buttons */
.btn-primary {
    background: #ff6a61;
    border: none;
    font-weight: 600;
    border-radius: 25px;
    padding: 0.5rem 1.2rem;
    box-shadow: 4px 4px 12px rgba(0,0,0,0.5), -4px -4px 12px rgba(255,255,255,0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.btn-primary:hover {
    transform: scale(1.05);
    box-shadow: 6px 6px 18px rgba(0,0,0,0.7), -6px -6px 18px rgba(255,255,255,0.1);
}

/* Modal Footer */
.modal-footer {
    /* background: #1b1b1f; */
    border-top: none;
    justify-content: flex-end;
}

/* Close Button */
.btn-close {
    filter: brightness(2);
}

/* Responsive */
@media(max-width:992px){
    .profile-section img#mainImage { max-height: 250px; }
    .modal-header { flex-direction: column; gap: 0.5rem; }
    .card-body p { font-size: 0.9rem; }
}

/* Smooth image swap animation */
.profile-section img {
    transition: transform 0.3s ease, opacity 0.3s ease;
}

</style>
<div class="modal" id="viewProfile">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-8 mb-3">
                        <div class="white_box mb-3 d-flex justify-content-between">
                            <div class="card h-100 w-100 {{ count($data['photos']) > 0 ? 'profile-section' : '' }}">
                                <img src="{{ $usr->photo }}" class="center card-img-top" id="mainImage" alt="Profile Image" style="height: 300px; object-fit: cover;">
                                <div class="card-body d-flex flex-column justify-content-between">
                                    <div class="d-flex justify-content-center">
                                         @if($usr->interest == 0 && $usr->interest_action == 0)
                                        <div style="cursor: pointer"><span class="badge rounded-pilll bg-success p-2 interest-action" data-url="{{ route('send-interest',['id' => $usr->id,'status' => 0]) }}">Sent Interest <i class="ti-control-play"></i></span></div>
                                        @elseif($usr->interest_action == 2 || $usr->interest == 1)
                                        @else
                                        <div style="cursor: pointer"><span class="badge rounded-pilll bg-success p-2 interest-action" data-url="{{ route('send-interest',['id' => $usr->id,'status' => 1]) }}">Accept <i class="ti-check"></i></span></div>
                                        <div style="margin-left:10px;cursor: pointer"><span class="badge rounded-pilll bg-danger p-2 interest-action" data-url="{{ route('send-interest',['id' => $usr->id,'status' => 2]) }}">Reject <i class="ti-close"></i></span></div>
                                        @endif
                                        @if($usr->like == "Yes")
                                        <div style="cursor: pointer"><span class="badge rounded-pilll bg-danger p-2 like-action" data-id="{{ $usr->id }}" data-url="{{ route('like-profile') }}" data-status="0" data-token="{{ csrf_token() }}">Unlike <i class="ti-heart" ></i></span></div>
                                        @else
                                        <div style="margin-left:10px;cursor: pointer"><span class="badge rounded-pilll bg-dark p-2 like-action"  data-id="{{ $usr->id }}" data-url="{{ route('like-profile') }}" data-status="1" data-token="{{ csrf_token() }}">Like <i class="ti-heart" style="color:red"></i></span></div>
                                        @endif
                                        @if($usr->shortlisted == "No")
                                        <div style="margin-left:10px;cursor: pointer"><span class="badge rounded-pilll bg-info p-2 shortlist-action" data-id="{{ $usr->id }}" data-url="{{ route('short-profile') }}"  data-token="{{ csrf_token() }}">Shortlist <i class="ti-pin-alt" ></i></span></div>
                                        @else
                                        <div style="margin-left:10px;cursor: pointer"><span class="badge rounded-pilll bg-info p-2">Shortlisted <i class="ti-pin-alt" ></i></span></div>
                                        @endif
                                    </div>
                                    <div>
                                        <p class="card-text">{{ $usr->age_years }}y |  {{ $usr->height }} ft</p>
                                        <h6 class="card-text ">{{ $usr->full_name }} | {{ $usr->profile_id }}</h6>
                                        <p class="card-text"><i class="ti-location-pin"></i> {{ $usr->city_living_in }}, {{ $usr->state_living_in }}</p>
                                    </div>
                                </div>
                            </div>
                        @if(count($data['photos']) > 0 )
                        <div class="gallery row g-3" data-cc="{{ count($data['photos']) }}">
                            @foreach($data['photos'] as $usrimg)
                                <div class="gallery-item col-12 col-md-6 col-lg-4">
                                    <img src="{{ 'https://himrishtey.com/photos/photo_gallery/' . $usrimg->photo }}" 
                                        alt="Gallery Image" 
                                        class="img-fluid w-100 rounded">
                                </div>
                            @endforeach
                        </div>
                        @endif
                        </div>
                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-#022e5b ">
                                    Basic Details
                                </div>
                                <div class="card-body">
                                    <p>Profile created for:  {{ $usr->profile_created_for }} | {{ $usr->age_years }}y </p>
                                    <p>Profile ID -  {{ $usr->profile_id }} | {{ $usr->religion }} | {{ $usr->cast }} | {{ $usr->city_living_in }}</p>
                                    <p><span class="badge bg-secondary">{{ $usr->marital_status }}</span> @if($usr->no_of_child > 0 )<span class="badge bg-secondary">{{ $usr->no_of_child }}</span>@endif</p>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">
                                    Astro & Kundali Details
                                </div>
                                <div class="card-body">
                                    <p><b>Date of Birth:</b> {{ \Carbon\Carbon::parse($usr->birth_date_time)->toDateString() }}</p>
                                    <p>Time of Birth: {{ \Carbon\Carbon::parse($usr->birth_date_time)->format('h:i A') }}</p>
                                    <p>Place of Birth: {{ $usr->birth_place }}</p>
                                    <p>Manglik : {{ $usr->manglik }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">
                                    Religion Information
                                </div>
                                <div class="card-body">
                                    <p>Community: {{ $usr->cast }}</p>
                                    <p>Sub Community: {{ $usr->sub_cast }}</p>
                                    <p>Gotra: {{ $usr->gotra }}</p>
                                    <p>Native Place: {{ $usr->birth_place }}</p>
                                    <p>Mother Tongue: {{ $usr->mother_tongue }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">
                                    Contact Information
                                </div>
                                <div class="card-body">
                                <p id="contact_number">
                                    Contact Number: 
                                    {{ $usr->profile_viewed == "No" ? substr($usr->mobile_number,0,2).'********' : $usr->mobile_number }}
                                </p>
                                <p id="whatsapp_number">
                                    Whatsapp: 
                                    {{ $usr->profile_viewed == "No" ? substr($usr->whatsapp_number,0,2).'********' : $usr->whatsapp_number }}
                                </p>
                                <p id="email">
                                    Email: 
                                    {{ $usr->profile_viewed == "No" ? substr($usr->email,0,2).'********' : $usr->email }}
                                </p>
                                @if($usr->profile_viewed == "No")
                                    <button type="button" id="unlock_btn" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#unlockContactModal">
                                        Unlock Contact ({{ $usr->profile_view_price }})
                                    </button>
                                @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">Family Details</div>
                                <div class="card-body">
                                    <p>Family Type: {{ $usr->family_type }}</p>
                                    <p>Father Occupation: {{ $usr->father_occupation }}</p>
                                    <p>Mother Occupation: {{ $usr->mother_occupation }}</p>
                                    <p>Brothers: {{ $usr->no_of_brothers }}</p>
                                    <p>Married Brothers: {{ $usr->married_brothers }}</p>
                                    <p>Sisters: {{ $usr->no_of_sisters }}</p>
                                    <p>Married Sisters: {{ $usr->married_sisters }}</p>
                                    <p>Native Place: {{ $usr->native_place }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">Lifestyle</div>
                                <div class="card-body">
                                    <p>Diet: {{ $usr->diet }}</p>
                                    <p>Smoking: {{ $usr->is_smoking }}</p>
                                    <p>Drinking: {{ $usr->is_drinking }}</p>
                                    <p>Any Disability: {{ $usr->any_disability }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">Partner Preferences</div>
                                <div class="card-body">
                                    <p>Height: {{ $usr->partner_height_from }} - {{ $usr->partner_height_to }}</p>
                                    <p>Age: {{ $usr->partner_age_from }} - {{ $usr->partner_age_to }}</p>
                                    <p>Marital Status: {{ $usr->looking_for }}</p>
                                    <p>Religion & Mother Tongue: {{ $usr->partner_religion }}</p>
                                    <p>Community: {{ $usr->partner_cast }}</p>
                                    <p>Is Manglik: {{ $usr->is_partner_manglik }}</p>
                                    <p>Education: {{ $usr->partner_education }}</p>
                                    <p>Occupation: {{ $usr->partner_occupation }}</p>
                                    <p>Annual Income: {{ $usr->partner_annual_income_from }} - {{ $usr->partner_annual_income_to }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="white_box mb-3">
                            <div class="card">
                                <div class="card-header bg-purple ">About</div>
                                <div class="card-body">
                                    <p>{{ $usr->about_me }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info text-white" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal show" id="unlockContactModal" tabindex="-1" aria-labelledby="unlockContactModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="unlockContactModalLabel">Unlock Contact</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="unlockContactForm" action="{{ route('unlock.contact', $usr->id) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <p>
                        Unlocking this contact will cost 
                        <strong>{{ $usr->profile_view_price }} credits</strong> from your wallet.
                    </p>
                    <p>Your current balance: 
                        <strong>{{ $wallet->wallet_balance ?? 0 }}</strong> credits
                    </p>
                    @if(($wallet->wallet_balance ?? 0) < $usr->profile_view_price)
                        <div class="alert alert-danger">
                            You don’t have enough balance. Please recharge your wallet.
                        </div>
                    @endif
                </div>
                <input type="hidden" name="unlock_price" value="{{ $usr->profile_view_price }}">
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                    @if(($wallet->wallet_balance ?? 0) >= $usr->profile_view_price)
                        <button type="submit" class="btn btn-info">Confirm Unlock</button>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>
<script>
  jQuery(document).ready(function($){
        $(".gallery img").click(function(){
            let newSrc = $(this).attr("src");
            $("#mainImage").fadeOut(200, function(){
                $(this).attr("src", newSrc).fadeIn(200);
            });
        });
    })

$(document).ready(function () {
    $('#unlockContactForm').on('submit', function (e) {
        e.preventDefault();

        let form = $(this);
        let url = form.attr('action');

        $.ajax({
            url: url,
            type: "POST",
            data: form.serialize(),
            success: function (response) {
                if (response.status === 'success') {
                    $('#contact_number').text("Contact Number: " + response.mobile_number);
                    $('#whatsapp_number').text("Whatsapp: " + response.whatsapp_number);
                    $('#email').text("Email: " + response.email);
                    $('#wallet_balance').text(response.wallet_balance);
                    $('#unlock_btn').remove();
                    $('#unlockContactModal').modal('hide');
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert("Something went wrong!");
            }
        });
    });
});

</script>

