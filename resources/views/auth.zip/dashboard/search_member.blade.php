@extends('layouts.app')
@section('content')
<section class="home-area">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar_area">
                    <div class="side-box">
                        <span class="side-box-title"></span>
                        <div class="login-dp">
                            @if($data['member']->photo != '')
                            <img src="https://himrishtey.com/photos/photo/{{ $data['member']->photo }} " alt="" />
                            @else
                                @if($data['member']->gender == 'Male')
                                    <img src="https://himrishtey.com/img/boy.jpg" alt="" />
                                @elseif($data['member']->gender == 'Female')
                                    <img src="https://himrishtey.com/img/girl.jpg" alt="" />
                                @else
                                    <img src="https://himrishtey.com/img/no-image.jpg" alt="" />
                                @endif
                            @endif
                        </div>
                        <div class="login-name center">Hello, {{ $data['member']->full_name}}</div>
                        <div class="login-name center">ID : {{ $data['member']->profile_id}}</div>

                        <div class="pp-buttons">
                            <a href="#" style="text-align: center;width: 100%;" class="msbtn mbc1"><i
                                    class="fa fa-user-o" aria-hidden="true"></i> Edit Profile</a>
                            <a href="#" style="text-align: center;width: 100%;" class="msbtn mbc2"><i
                                    class="fa fa-level-up" aria-hidden="true"></i> Update Plan</a>
                        </div>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 25%"
                                aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>

                        </div>
                        <div class="">
                            Profile is {{ $data['member']->profile_completed }} completed
                        </div>
                    </div>

                    <div class="side-box">
                        <div class="side-box-title">Membership</div>
                        <div class="">
                            <div class="lofl">
                                Membership<span> {{ $data['plan']->plan_name }}</span>
                            </div>
                            <div class="lofl">
                                Plan Days<span>{{ $data['plan']->duration_days}}</span>
                            </div>
                            <div class="lofl">
                                Profile View<span>{{ $data['plan']->view_profile}}</span>
                            </div>
                            <div class="lofl">
                                Contact View<span>{{ $data['plan']->view_contact}}</span>
                            </div>
                        </div>
                    </div>

                    <div class="side-box">
                        <div class="side-box-title">List of profiles</div>
                        <div class="">
                            <div class="lofl">
                                Short Listed Profiles<span>{{ $data['shortlisted']}}</span>
                            </div>
                            <div class="lofl">
                                Profiles I Viewed <span>{{ $data['iviewed']}}</span>
                            </div>
                            <div class="lofl">
                                Viewed My Profiles<span>{{ $data['viewed']}}</span>
                            </div>
                        </div>
                    </div>

                    <div class="side-box">
                        <div class="side-box-title">Interests</div>
                        <div class="">
                            <div class="lofl">
                                Interest Send<span>{{ $data['interestSent']}}</span>
                            </div>
                            <div class="lofl">
                                Interest Received<span>{{ $data['interestReceived']}}</span>
                            </div>
                        </div>
                    </div>

                    <div class="side-box">
                        <div class="side-box-title">Quick Search</div>
                        <div class="search-box">
                            <form method="GET" action="{{ route('quick-search') }}">
                                <div class="row">
                                    <div class="form-group-sm col-md-6">
                                        <label>Age From</label><span class="req-star"><sup><i
                                                    class="fa fa-star"></i></sup></span>
                                        <input type="number" class="form-control small-field" id="partner_age_from"
                                            name="partner_age_from" required />
                                    </div>
                                    <div class="form-group-sm col-md-6">
                                        <label>Age To</label><span class="req-star"><sup><i
                                                    class="fa fa-star"></i></sup></span>
                                        <input type="number" class="form-control small-field" id="partner_age_to"
                                            name="partner_age_to" required />
                                    </div>

                                    <div class="form-group-sm col-md-6">
                                        <label>Height From</label><span class="req-star"><sup><i
                                                    class="fa fa-star"></i></sup></span>
                                        <input type="number" class="form-control small-field" id="partner_height_from"
                                            name="partner_height_from" required />
                                    </div>
                                    <div class="form-group-sm col-md-6">
                                        <label>Height To</label><span class="req-star"><sup><i
                                                    class="fa fa-star"></i></sup></span>
                                        <input type="number" class="form-control small-field" id="partner_height_to"
                                            name="partner_height_to" required />
                                    </div>

                                    <div class="form-group-sm col-md-12">
                                        <label>Religion</label><span class="req-star"><sup><i
                                                    class="fa fa-star"></i></sup></span>
                                        <select multiple="multiple" class="chosen-select form-control small-field"
                                            id="partner_religion" name="partner_religion" required>
                                            <option></option>


                                        </select>
                                    </div>
                                    <div class="center">
                                        <button style="margin-bottom: 4px;" class="hr-button">Search</button>
                                   </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="tab-pane active">
                    @foreach($data['members'] as $member)
                    <div class="member-box">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="member-profile-pic">
                                @if($member['photo'] != '')
                                <img src="https://himrishtey.com/photos/photo/{{ $member['photo'] }} " alt="" />
                                @else
                                    @if($member['gender'] == 'Male')
                                        <img src="https://himrishtey.com/img/boy.jpg" alt="" />
                                    @elseif($member['gender'] == 'Female')
                                        <img src="https://himrishtey.com/img/girl.jpg" alt="" />
                                    @else
                                        <img src="https://himrishtey.com/img/no-image.jpg" alt="" />
                                    @endif
                                @endif
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="member-profile-box">
                                    <span class="member_id">ID {{ $member['profile_id'] }}</span>
                                    <a href="#" class="mbtn mbc1 disabled-btn"><i class="fa fa-user"
                                            aria-hidden="true"></i> View Profile</a>
                                    <a href="#" class="mbtn mbc1 disabled-btn"><i class="fa fa-address-book-o"
                                            aria-hidden="true"></i> View Contact</a>
                                    <div class="member-profile-detail">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <table class="member-table">
                                                    <tr>
                                                        <td>Age:</td>
                                                        <td class="aright">{{ $member['age'] }} Years ({{ $member['birthdatetime'] }})</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Height:</td>
                                                        <td class="aright">{{ $member['height'] }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Religion:</td>
                                                        <td class="aright">{{ $member['religion'] }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Cast:</td>
                                                        <td class="aright">{{ $member['cast'] }}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-6">
                                                <table class="member-table">
                                                    <tr>
                                                        <td>Education:</td>
                                                        <td class="aright">{{ $member['education'] }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Location:</td>
                                                        <td class="aright">{{ $member['location'] }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Occupation:</td>
                                                        <td class="aright">{{ $member['occupation'] }}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Mother Tongue:</td>
                                                        <td class="aright">{{ $member['mother_tongue'] }}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="profile-buttons">
                                        <button class="mbutton mbc1" data-toggle="modal"
                                            data-target="#send_message_modal"><i class="fa fa-envelope-o"
                                                aria-hidden="true"></i> Send Message</button>
                                        <div id="slp-btn-" class="profile-button"><button class="mbutton mbc2"><i
                                                    class="fa fa-filter" aria-hidden="true"></i> Shortlisted</button>
                                        </div>
                                        <div id="blp-btn" class="profile-button"><button class="mbutton mbc3"><i
                                                    class="fa fa-ban" aria-hidden="true"></i> Blocklisted</button></div>
                                        <div id="si-btn" class="profile-button"><button class="mbutton mbc4"><i
                                                    class="fa fa-user" aria-hidden="true"></i> Send Interest</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

            </div>
        </div>
    </div>
</section>
@endsection