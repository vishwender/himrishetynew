@extends('dashboard.layouts.app')
@section('content')
<div class="row justify-content-center">
    <div class="col-lg-12">
        <div class="single_element">
            <div class="quick_activity">
                <div class="row">
                    <div class="col-12">
                        <div class="quick_activity_wrap">
                            <div class="single_quick_activity d-flex home_state" data-profile="profile_viewed"
                                data-url="{{ route('stats-profiles') }}">
                                <div class="icon">
                                    <img src="{{ asset('assets/user/img/icon/profile.png') }}" alt="">
                                </div>
                                <div class="count_content">
                                    <h3><span class="counter">{{ $data['iviewed']}}</span> </h3>
                                    <p>Profile Visit</p>
                                </div>
                            </div>
                            <div class="single_quick_activity d-flex home_state" data-profile="likes"
                                data-url="{{ route('stats-profiles') }}">
                                <div class="icon">
                                    <img src="{{ asset('assets/user/img/icon/likes.png') }}
                                    " alt="">
                                </div>
                                <div class="count_content">
                                    <h3><span class="counter">{{ $data['iLikes']}}</span> </h3>
                                    <p>Likes</p>
                                </div>
                            </div>
                            <div class="single_quick_activity d-flex home_state" data-profile="interest"
                                data-url="{{ route('stats-profiles') }}">
                                <div class="icon">
                                    <img src="{{ asset('assets/user/img/icon/user.png') }}" alt="">
                                </div>
                                <div class="count_content">
                                    <h3><span class="counter">{{ $data['interestSent'] }}</span> </h3>
                                    <p>Interest</p>
                                </div>
                            </div>

                            <div class="single_quick_activity d-flex home_state" data-profile="contact"
                                data-url="{{ route('stats-profiles') }}">
                                <div class="icon">
                                    <img src="{{ asset('assets/user/img/icon/users-icon.png') }}" alt="">
                                </div>
                                <div class="count_content">
                                    <h3><span class="counter"> {{ $data['contact'] }}</span> </h3>
                                    <p>Viewed</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(count($data['recents']) > 0 )
    <div class="col-xl-12">
        <div class="white_box card_height_100">
            <div class="box_header border_bottom_1px d-flex justify-content-between align-items-center">
                <div class="main-title">
                    <h3 class="mb_25">Recent Profiles</h3>
                </div>
                <a href="javascirpt:void('0')" class="btn btn-sm btn-danger view_all_slider" data-view="view"
                    data-profile="recent" data-url="{{ route('recent-profiles') }}">
                    View All
                </a>
            </div>
            <div class="staf_list_wrapper sraf_active owl-carousel">
                @foreach($data['recents'] as $recent)
                <div class="col-md-4">
                    <a href="javascript:void(0)" class="viewProfile"
                        data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                        <div class="card mb-3 card-width">
                            <img class="card-img-top" src="{{ $recent['photo'] }}" height="380" alt="Card image cap">
                            <div class="product-detail">
                                <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                                <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} |
                                    {{ $recent['cast'] }}</span>
                                <blockquote>
                                    <p>{{ $recent['religion'] }}</p>
                                    <p>{{ $recent['education'] }}</p>
                                    <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif


    @if(count($data['verifiedUsers']) > 0 )
    <div class="col-xl-12">
        <div class="white_box card_height_100">
            <div class="box_header border_bottom_1px  ">
                <div class="main-title">
                    <h3 class="mb_25">Verified Profiles</h3>
                </div>
                <a href="javascript:void('0')" class="btn btn-sm btn-danger view_all_slider" data-view="view"
                    data-profile="verified" data-url="{{ route('recent-profiles') }}">
                    View All
                </a>
            </div>
            <div class="staf_list_wrapper sraf_active owl-carousel">
                @foreach($data['verifiedUsers'] as $recent)
                <div class="col-md-4">
                    <a href="javascript:void(0)" class="viewProfile"
                        data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                        <div class="card mb-3 card-width">
                            <img class="card-img-top" src="{{ $recent['photo'] }}" height="380" alt="Card image cap">
                            <div class="product-detail">
                                <h5 class="card-title heading text-center"><span class="verified-icon"><span class="ti-medall"></span></span>{{ $recent['full_name'] }}</h5>
                                <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} |
                                    {{ $recent['cast'] }}</span>
                                <blockquote>
                                    <p>{{ $recent['religion'] }}</p>
                                    <p>{{ $recent['education'] }}</p>
                                    <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
    @if(count($data['viewed']) > 0 )
    <div class="col-xl-12">
        <div class="white_box card_height_100">
            <div class="box_header border_bottom_1px  ">
                <div class="main-title">
                    <h3 class="mb_25">Who Viewed My Profile</h3>
                </div>
                <a href="javascript:void('0')" class="btn btn-sm btn-danger view_all_slider" data-view="view"
                    data-profile="viewed" data-url="{{ route('recent-profiles') }}">
                    View All
                </a>
            </div>
            <div class="staf_list_wrapper sraf_active owl-carousel">
                @foreach($data['viewed'] as $recent)
                <div class="col-md-4">
                    <a href="javascript:void(0)" class="viewProfile"
                        data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                        <div class="card mb-3  card-width">
                            <img class="card-img-top" src="{{ $recent['photo'] }}" height="380" alt="Card image cap">
                            <div class="product-detail">
                                <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                                <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} |
                                    {{ $recent['cast'] }}</span>
                                <blockquote>
                                    <p>{{ $recent['religion'] }}</p>
                                    <p>{{ $recent['education'] }}</p>
                                    <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
    @if(count($data['shortlist']) > 0 )
    <div class="col-xl-12">
        <div class="white_box card_height_100">
            <div class="box_header border_bottom_1px  ">
                <div class="main-title">
                    <h3 class="mb_25">Shortlisted Profiles</h3>
                </div>
                <a href="javascript:void('0')" class="btn btn-sm btn-danger view_all_slider" data-view="view"
                    data-profile="shortlist" data-url="{{ route('recent-profiles') }}">
                    View All
                </a>
            </div>
            <div class="staf_list_wrapper sraf_active owl-carousel">
                @foreach($data['shortlist'] as $recent)
                <div class="col-md-4">
                    <a href="javascript:void(0)" class="viewProfile"
                        data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                        <div class="card mb-3 card-width">
                            <img class="card-img-top" src="{{ $recent['photo'] }}" height="380" alt="Card image cap">
                            <div class="product-detail">
                                <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                                <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} |
                                    {{ $recent['cast'] }}</span>
                                <blockquote>
                                    <p>{{ $recent['religion'] }}</p>
                                    <p>{{ $recent['education'] }}</p>
                                    <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
    @if(count($data['matching_profiles']) > 0 )
    <div class="col-xl-12">
        <div class="white_box card_height_100">
            <div class="box_header border_bottom_1px  ">
                <div class="main-title">
                    <h3 class="mb_25">Matching Profiles</h3>
                </div>
                <a href="javascript:void('0')" class="btn btn-sm btn-danger view_all_slider" data-view="view"
                    data-profile="matching" data-url="{{ route('recent-profiles') }}">
                    View All
                </a>
            </div>
            <div class="staf_list_wrapper sraf_active owl-carousel">
                @foreach($data['matching_profiles'] as $recent)
                <div class="col-md-4">
                    <a href="javascript:void(0)" class="viewProfile"
                        data-url="{{ route('view-profile', ['id' => $recent['id']]) }}" data-id="{{ $recent['id'] }}">
                        <div class="card mb-3 card-width">
                            <img class="card-img-top" src="https://himrishtey.com/photos/photo/{{ $recent['photo'] }}" height="380" alt="Card image cap">
                            <div class="product-detail">
                                <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                                <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }} |
                                    {{ $recent['cast'] }}</span>
                                <blockquote>
                                    <p>{{ $recent['religion'] }}</p>
                                    <p>{{ $recent['education'] }}</p>
                                    <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
</div>
@endsection