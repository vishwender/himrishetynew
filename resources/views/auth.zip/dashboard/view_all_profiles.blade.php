<div class="modal fade" id="view_all_profiles" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header bg-gradient-primary text-white rounded-top-4">
                <h4 class="modal-title mb-0">
                    @if($profileFor == "recent") Recent Profiles
                    @elseif($profileFor == "verified") Verified Profiles
                    @elseif($profileFor == "shortlist") Shortlisted Profiles
                    @elseif($profileFor == "viewed") Who Viewed My Profile
                    @elseif($profileFor == "matching") Matching Profiles
                    @endif
                </h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body bg-light">
                <div class="row g-4" id="recentProfiles">
                    @foreach($users as $recent)
                    <div class="col-md-4">
                        <a href="javascript:void(0)" class="viewProfile"
                            data-url="{{ route('view-profile', ['id' => $recent['id']]) }}"
                            data-id="{{ $recent['id'] }}">
                            <div class="card mb-3 card-width">
                                <img class="card-img-top" src="{{ $recent['photo'] }}" height="380"
                                    alt="Card image cap">
                                <div class="product-detail">
                                    <h5 class="card-title heading text-center">{{ $recent['full_name'] }}</h5>
                                    <span class="subheading">{{ $recent['age_years'] }} years | {{ $recent['height'] }}
                                        |
                                        {{ $recent['cast'] }}</span>
                                    <blockquote>
                                        <p>{{ $recent['religion'] }}</p>
                                        <p>{{ $recent['education'] }}</p>
                                        <p>{{ $recent['city_living_in'] . ', ' . $recent['state_living_in'] }}</p>
                                    </blockquote>
                                </div>
                            </div>
                        </a>
                    </div>
                    @endforeach
                </div>

                <div class="text-center mt-4">
                    <button id="loadMore" class="btn btn-primary px-4 py-2 rounded-pill fw-semibold shadow-sm"
                        data-offset="30" data-profile="{{ $profileFor }}"
                        data-url="{{ $stats == 'stats' ? route('all-stats-profiles') : route('all-recent-profiles') }}">
                        Load More
                    </button>
                </div>
            </div>

            <div class="modal-footer border-0">
                <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>