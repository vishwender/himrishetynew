<div class="modal fade" id="refund_model" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content p-4">

            <div class="modal-header border-0">
                <h3 class="fw-bold mb-0">Refund & Cancellation</h3>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body text-start terms-overview mb-5">
                <h5 class="fw-bold mb-3">OVERVIEW</h5>
                <p class="mb-3">
                   himrishtey.com believes in helping its community as far as possible. In the instance of you chose to terminate your membership, 
                   the MEMBERSHIP FEES ARE NOT REFUNDABLE under any circumstances. The membership with himrishtey is for your personal use only 
                   and it is not transferable, and you may not authorze other to use your membership, 
                   you may not assign or transfer your membership to any person or entity.
                </p>
            </div>

        </div>
    </div>
</div>