<div class="modal" id="planModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ $data['membership']['plan_name']}}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row justify-content-center">
                    @foreach($data['plans'] as $plan)
                    <div class="col-md-6 mb-4">
                        <div class="card border-0 shadow-lg h-100 text-center plan-card">
                            <div class="card-body">
                                <span class="mb-3">
                                    <b class="badge bg-primary mb-3">{{ $plan['discount_percentage'] }}%</b> OFF
                                </span>
                                <h3 class="fw-bold text-uppercase text-dark mb-2">
                                    {{ $plan['plan_name'] }}
                                </h3>
                                <p class="text-muted mb-2">
                                    Allowed Contacts: <strong>{{ $plan['view_contact'] }}</strong>
                                </p>
                                <h4 class="fw-bold text-infor mb-2">
                                    ₹{{ $plan['final_cost'] }}
                                    <small class="text-muted">/ {{ $plan['duration_days'] }} days</small>
                                </h4>
                                <p class="text-decoration-line-through text-muted">
                                    ₹{{ $plan['plan_cost'] }}
                                </p>
                                <a href="{{ route('membership.checkout', $plan->id) }}" class="btn btn-info w-100 mt-3 text-white">Buy Now</a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <div class="row card mb-3">
                    <h3 class="mb-2 mt-2 p-2">Description</h3>
                    <p class="color-black">{{ $data['membership']['plan_description'] }} </p>
                </div>
                <div class="row card mb-3 mt-3 p-2">
                    <h3 class="mb-2 mt-2">Terms and Conditions</h3>
                    <p class="color-black">{{ $data['membership']['plan_description'] }} </p>
                </div>
                <div class="row card">
                    <h3 class="mb-2 mt-2 p-2">Features</h3>
                    @php
                        $descriptions = explode('_', $data['membership']['plan_guide']);
                    @endphp
                    <ul class="list-unstyled">
                        @foreach ($descriptions as $item)
                            <li>✅ {{ trim($item) }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-info text-white" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>