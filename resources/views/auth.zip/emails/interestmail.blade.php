<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $data['subject'] ?? 'Notification' }}</title>
    <style>
        body {
            background-color: #f6f9fc;
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .email-container {
            max-width: 600px;
            background: #fff;
            margin: 40px auto;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }
        .header {
            background-color: #4F46E5;
            color: #fff;
            text-align: center;
            padding: 30px 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .content {
            padding: 30px 25px;
            line-height: 1.6;
        }
        .content h2 {
            color: #111827;
            font-size: 20px;
            margin-bottom: 10px;
        }
        .content p {
            font-size: 15px;
            color: #444;
            margin-bottom: 20px;
        }
        .button {
            display: inline-block;
            background-color: #4F46E5;
            color: #fff !important;
            padding: 12px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
        }
        .footer {
            background-color: #f3f4f6;
            color: #6b7280;
            font-size: 13px;
            text-align: center;
            padding: 20px;
        }
        .footer a {
            color: #4F46E5;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header -->
        <div class="header">
            <h1>{{ config('app.name') }}</h1>
        </div>

        <!-- Content -->
        <div class="content">
            <h2>Hello {{ $details['name'] ?? 'User' }},</h2>
            <p>{{ $details['message'] ?? 'This is a notification email.' }}</p>

            @if(!empty($data['button_url']) && !empty($data['button_text']))
                <p style="text-align:center;">
                    <a href="{{ $data['button_url'] }}" class="button" target="_blank">
                        {{ $data['button_text'] }}
                    </a>
                </p>
            @endif

            <p>Best regards,<br><strong>{{ $data['from_name'] ?? config('app.name') }} Team</strong></p>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Need help? <a href="mailto:himrishtey@gmail.com">Contact Support</a></p>
            <p>&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
