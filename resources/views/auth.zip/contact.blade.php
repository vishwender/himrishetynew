@extends('layouts.app')
@section('content')
<section class="banner_area">
    <div class="container">
        <div class="banner_inner_content">
            <h3>Contact Us</h3>
            <ul>
                <li class="active"><a href="#">Home</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </div>
    </div>
</section>

<!--================Get Contact Area =================-->
<section class="get_contact_area">
    <div class="container">
        <div class="row get_contact_inner">
            <div class="col-md-6">
                <div class="left_ex_title">
                    <h2>get in <span>touch</span></h2>
                </div>
                <form class="contact_us_form row m0" action="#" method="post" id="contactForm" novalidate="novalidate">
                    <div class="form-group col-md-12">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Name">
                    </div>
                    <div class="form-group col-md-12">
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                    </div>
                    <div class="form-group col-md-12">
                        <input type="text" class="form-control" id="number" name="number" placeholder="Contact Number">
                    </div>
                    <div class="form-group col-md-12">
                        <textarea class="form-control" name="message" id="message" rows="1"
                            placeholder="Message"></textarea>
                    </div>
                    <div class="form-group col-md-12">
                        <button type="submit" value="submit" class="btn submit_btn form-control">submit now</button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <div class="right_contact_info">
                    <div class="contact_info_title">
                        <h3>Contact info</h3>
                        <p>Have any Queries? Let us know. We will clear it for you at the best.</p>
                    </div>
                    <div class="contact_info_list">
                        <div class="media">
                            <div class="media-left">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="media-body">
                                <h4>Office</h4>
                                <p>Maranda, Kasoti, Palampur Kangra <br /> Himachal Pradesh 176102</p>
                            </div>
                        </div>
                        <div class="media">
                            <div class="media-left">
                                <i class="fa fa-envelope-o"></i>
                            </div>
                            <div class="media-body">
                                <h4>Email</h4>
                                <a href="#">himrishtey@gmail.com</a>

                            </div>
                        </div>
                        <div class="media">
                            <div class="media-left">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="media-body">
                                <h4>Mobile</h4>
                                <a href="#">+91 9857102002</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Get Contact Area =================-->

<!--================Map Area =================-->
<section class="contact_map_area">
    <div class="container">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13521.911187844873!2d76.5015937025635!3d32.083370048723125!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x58f1ba1179f02daa!2sHimRishtey%20No.1%20Matrimonial%20%26%20Marriage%20Bureau%20In%20Kangra%20Himachal%20Pradesh!5e0!3m2!1sen!2sin!4v1633962019811!5m2!1sen!2sin"
            style="width:100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
</section>
<!--================End Map Area =================-->
@endsection