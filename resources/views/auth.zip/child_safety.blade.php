@extends('layouts.app')
@section('content')
<section class="banner_area">
    <div class="container">
        <div class="banner_inner_content">
            <h3>Child Safety Standard</h3>
            <ul>
                <li class="active"><a href="{{ route('welcome') }}">Home</a></li>
                <li><a href="#">Child Safety Standard</a></li>
            </ul>
        </div>
    </div>
</section>

<section class="page-section">
    <div class="container">
        <div class="page-box">
            <div class="explor_title row m0">
                <div class="left_ex_title1">
                    <h2><span>Child Safety Standard</span></h2>
                    <p><b>OVERVIEW</b></p>
                    <p>HimRishtey’s Commitment to Preventing Child Sexual Abuse and Exploitation (CSAE)</p>
                    <p>At HimRishtey, the safety and security of our users are our top priority. We are deeply committed
                        to maintaining a safe environment that respects human dignity and protects
                        the vulnerable, including children. We have zero tolerance for any form of child sexual abuse
                        and exploitation.</p>

                    <p>Our Policy on Child Sexual Abuse and Exploitation.</p>
                    <p><b>We strictly prohibit the following:</b></p>
                    <p>Child Sexual Abuse Material (CSAM): Any content depicting or promoting child sexual abuse is
                        strictly forbidden.</p>
                    <p>Child Exploitation: Any act that involves exploiting children for personal, commercial, or sexual
                        purposes.</p>
                    <p>Inappropriate Behavior: Any form of communication, solicitation, or grooming directed towards
                        minors is not allowed.</p>
                    <p><b>Our Approach and Measures</b></p>
                    <p>Age Verification: We require users to confirm they are above 18 before creating an account.</p>
                    <p>Content Moderation: Our team actively monitors content to detect and remove inappropriate
                        materials.</p>
                    <p>User Reporting Mechanism: Users can report suspicious or inappropriate content, which we review
                        and act upon promptly.</p>
                    <p>Collaboration with Authorities: We cooperate with law enforcement agencies to report and prevent
                        CSAE.</p>
                    <p><b>Reporting and Support</b></p>
                    <p>If you come across any content or behavior violating our policy, please report it immediately
                        through our app or contact us at himrishtey@gmail.com.</p>
                    <p>We are committed to providing a safe and respectful environment for all our users. Your safety is
                        our priority.</p>
                    <p>HimRishtey Team</p>
                </div>
            </div>
            <!-- Page -->
        </div>
    </div>
</section>
@endsection